  <!-- JavaScript -->
  <script src="cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.html" integrity="sha512-QSkVNOCYLtj73J4hbmVoOV6KVZuMluZlioC+trLpewV8qMjsWqlIQvkn1KGX2StWvPMdWGBqim1xlC8krl1EKQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAAz77U5XQuEME6TpftaMdX0bBelQxXRlM"></script>
  <script src="unpkg.com/%40googlemaps/markerclusterer%402.0.13/dist/index.min.html"></script>

  <script src="js/vendors.js"></script>
  <script src="js/main.js"></script>