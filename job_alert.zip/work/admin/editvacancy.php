<?php include "config.php";
	session_start();
    if (!isset($_SESSION["username"]))
    {
        header("Location:login.php?mes=login_error");
    }
  else{
        $username=$_SESSION["username"];
        $sql="SELECT * FROM company WHERE company_mobile='$company_mobile'";
        $res=$connect->query($sql);
        $row=$res->fetch_assoc();
     
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "header.php"; ?>
</head>

<body data-barba="wrapper">


  <div class="preloader js-preloader">

  </div>


  <div class="header-margin"></div>
  <header data-add-bg="" class="header -dashboard bg-white js-header" data-x="header" data-x-toggle="is-menu-opened">
    <div data-anim="fade" class="header__container px-30 sm:px-20">
      <div class="-left-side">
        <a href="#!" class="header-logo" data-x="header-logo" data-x-toggle="is-logo-dark">
          <img src="img/general/logo.png" alt="logo icon">
          <img src="img/general/logo.png" alt="logo icon">
        </a>
      </div>

      <div class="row justify-between items-center pl-60 lg:pl-20">
        <div class="col-auto">
          <div class="d-flex items-center">
            <button data-x-click="dashboard">
              <i class="icon-menu-2 text-20"></i>
            </button>

            <div class="single-field relative d-flex items-center md:d-none ml-30">
              <input class="pl-50 border-light text-dark-1 h-50 rounded-8" type="email" placeholder="Search">
              <button class="absolute d-flex items-center h-full">
                <i class="icon-search text-20 px-15 text-dark-1"></i>
              </button>
            </div>
          </div>
        </div>

        <div class="col-auto">
          <div class="d-flex items-center">
            <div class="row items-center x-gap-5 y-gap-20 pl-20 lg:d-none">
              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-email-2 text-20"></i>
                </button>
              </div>

              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-notification text-20"></i>
                </button>
              </div>
            </div>

            <div class="pl-15">
              <img src="img/avatars/3.png" alt="image" class="size-50 rounded-22 object-cover">
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>


  <div class="dashboard" data-x="dashboard" data-x-toggle="-is-sidebar-open">
    <div class="dashboard__sidebar bg-white scroll-bar-1">
      <?php include "navbar.php"; ?>
    </div>

    <div class="dashboard__main">
      <div class="dashboard__content">
        <div class="row y-gap-20 justify-between items-end pb-20 lg:pb-40 md:pb-32">
          <div class="col-auto">

            <h1 class="text-30 lh-14 fw-600">Edit Vacancy</h1>
            <!-- <div class="text-15 text-light-1">Company Details</div> -->

          </div>

          <div class="col-auto">

          </div>
        </div>


        <div class="py-30 px-30 rounded-4 bg-white custom_shadow">
          <div class="tabs -underline-2 js-tabs">
            <div class="tabs__controls row x-gap-40 y-gap-10 lg:x-gap-20 js-tabs-controls">

              <div class="col-auto">
                <button class="tabs__button text-18 lg:text-16 text-light-1 fw-500 pb-5 lg:pb-0 js-tabs-button is-tab-el-active" data-tab-target=".-tab-item-1">Vacancy</button>
              </div>
            </div>

            <div class="tabs__content pt-30 js-tabs-content">
              <div class="tabs__pane -tab-item-1 is-tab-el-active">
                <div class="col-xl-10">
                  <div class="border-top-light mt-30 mb-30"></div>
                 
                    <div class="container">
                    <?php
                  if (isset($_GET["edit_id"])) {
                    $edit_id = $_GET["edit_id"];
                    $sql = "SELECT * FROM vacancy WHERE id='$edit_id'";
                    $res = $connect->query($sql);
                    while($row = $res->fetch_assoc()){


                    $id=$row["id"];
                    $job_title = $row["job_title"];
                    $job_type = $row["job_type"];
                    $company_name = $row["company_name"];
                    // $mobile = $row["mobile"];
                    $email = $row["email"];
                    $company_mobile = $row["company_mobile"];
                    $no_of_openings = $row["no_of_openings"];
                    $qualification = $row["qualification"];
                    $job_location = $row["job_location"];
                    $job_district = $row["job_district"];
                    $job_description = $row["job_description"];
                    $experience=$row["experience"];
                    $skills=$row["skills"];
                    $salary=$row["salary"];
                    $job_category=$row["job_category"];
                    }

                    ?>
                    <form action="" method="POST" enctype="multipart/form-data">
                      <div class="row x-gap-20 y-gap-20">
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Title</label>
                            <input type="text" name="job_title" value="<?php echo "$job_title"; ?>" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Type</label>
                            <!-- <input type="text" name="job_type" > -->
                            <select class="form-control input-sm" name="job_type" value="<?php echo "$job_type"; ?>">
                              <option value="">Select</option>
                              <option value="full time">full time</option>
                              <option value="part time">Part time</option>
                              <option value="intern">Intern</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Company Name</label>
                            <!-- <input type="text" name="company_name" > -->
                            <select class="form-control input-sm" name="company_name" value="<?php echo "$company_name"; ?>">
                            <?php
                        echo "<option value=''>Select</option>";
                        $sql = "SELECT * from company";
                        $res = $connect->query($sql);
                        while ($row = $res->fetch_assoc()) {
                            $company_name = $row["company_name"];
                            echo "<option value='$company_name'>$company_name</option>";
                        }

                        ?>
                        </select>
                          </div>
                        </div>
                        <!-- <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Mobile number</label>
                            <input type="text" name="mobile"  value="<?php echo "$mobile"; ?>">
                          </div>
                        </div> -->
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Email</label>
                            <input type="text" name="email" value="<?php echo "$email"; ?>" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Company mobile</label>
                            <!-- <input type="text" name="company_mobile" > -->
                            <select class="form-control input-sm" name="company_mobile" value="<?php echo "$company_mobile"; ?>">
                            <?php
                        echo "<option value=''>Select</option>";
                        $sql = "SELECT * from company";
                        $res = $connect->query($sql);
                        while ($row = $res->fetch_assoc()) {
                            $company_mobile = $row["company_mobile"];
                            echo "<option value='$company_mobile'>$company_mobile</option>";
                        }

                        ?>
                        </select>
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">No Of Openings</label>
                            <input type="text" name="no_of_openings" value="<?php echo "$no_of_openings"; ?>" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Qualification</label>
                            <input type="text" name="qualification" value="<?php echo "$qualification"; ?>" >
                          </div>
                        </div>

                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Location</label>
                            <input type="text" name="job_location" value="<?php echo "$job_location"; ?>" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job District</label>
                            <input type="text" name="job_district" value="<?php echo "$job_district"; ?>" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Description</label>
                            <input type="text" name="job_description"  value="<?php echo "$job_description"; ?>">
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Experience</label>
                            <input type="text" name="experience" value="<?php echo "$experience"; ?>" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Skills</label>
                            <input type="text" name="skills"  value="<?php echo "$skills"; ?>">
                          </div>
                        </div>

                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">salary</label>
                            <input type="text" name="salary" value="<?php echo "$salary"; ?>" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Category</label>
                            <input type="text" name="job_category" value="<?php echo "$job_category"; ?>" >
                          </div>
                        </div>


                        </div>

                        <!-- <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Profile</label>
                    
                            <img src="../job/upload/photo/<?php echo "$photo"; ?>" alt="">
                          </div>
                        </div> -->

                      </div>
                      <button class="btn btn-info mt-4" type="submit" name="submit">Update</button>
                    </form>
                  <?php  } ?>
                       <?php 
                      if (isset($_POST["submit"])) {
                        $job_title = $_POST["job_title"];
                        $job_type = $_POST["job_type"];
                        $company_name = $_POST["company_name"];
                        // $mobile = $_POST["mobile"];
                        $email = $_POST["email"];
                        $company_mobile = $_POST["company_mobile"];
                        $no_of_openings = $_POST["no_of_openings"];
                        $qualification = $_POST["qualification"];
                        $job_location = $_POST["job_location"];
                        $job_district = $_POST["job_district"];
                        $job_description = $_POST["job_description"];
                        $experience=$_POST["experience"];
                        $skills=$_POST["skills"];
                        $salary=$_POST["salary"];
                        $job_category=$_POST["job_category"];

                        // $temp = explode(".", $_FILES["profile"]["name"]); //file name get
                        // $profile = "profile$mobile." . end($temp);      //file name rename to photo and mobile no
                        // move_uploaded_file($_FILES["profile"]["tmp_name"], "upload/$profile"); //file uplode 



                        $sql="UPDATE vacancy SET job_title='$job_title', job_type='$job_type', company_name='$company_name', email='$email', company_mobile='$company_mobile', no_of_openings='$no_of_openings', qualification='$qualification', job_location='$job_location', job_district='$job_district', job_description='$job_description', experience='$experience', skills='$skills', salary='$salary', job_category='$job_category' WHERE id='$id' ";

                        if ($connect->query($sql)) {
                          echo "<script> alert('vacancy Update successfully'); window.location.replace('editvacancy.php?edit_id=$id');</script>";
                        } else {
                          echo "<script> alert('vacancy Update failed'); window.location.replace('editvacancy.php');</script>";
                        }
                      }
                      ?>

                    </div>
                    <hr>
                  


                </div>

              </div>
            </div>
          </div>


          <?php include "footer.php"; ?>
        </div>
      </div>
    </div>

    <?php include "footer_script.php"; ?>
</body>

</html>