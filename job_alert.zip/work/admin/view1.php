<?php include "config.php";  ?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include "header.php"; ?>


</head>

<body data-barba="wrapper">


  <div class="preloader js-preloader">
    
  </div>


  <div class="header-margin"></div>
  <header data-add-bg="" class="header -dashboard bg-white js-header" data-x="header" data-x-toggle="is-menu-opened">
    <div data-anim="fade" class="header__container px-30 sm:px-20">
      <div class="-left-side">
        <a href="#!" class="header-logo" data-x="header-logo" data-x-toggle="is-logo-dark">
          <img src="img/general/logo.png" alt="logo icon">
          <img src="img/general/logo.png" alt="logo icon">
        </a>
      </div>

      <div class="row justify-between items-center pl-60 lg:pl-20">
        <div class="col-auto">
          <div class="d-flex items-center">
            <button data-x-click="dashboard">
              <i class="icon-menu-2 text-20"></i>
            </button>

            <div class="single-field relative d-flex items-center md:d-none ml-30">
              <input class="pl-50 border-light text-dark-1 h-50 rounded-8" type="email" placeholder="Search">
              <button class="absolute d-flex items-center h-full">
                <i class="icon-search text-20 px-15 text-dark-1"></i>
              </button>
            </div>
          </div>
        </div>

        <div class="col-auto">
          <div class="d-flex items-center">
            <div class="row items-center x-gap-5 y-gap-20 pl-20 lg:d-none">
              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-email-2 text-20"></i>
                </button>
              </div>

              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-notification text-20"></i>
                </button>
              </div>
            </div>

            <div class="pl-15">
              <img src="img/avatars/3.png" alt="image" class="size-50 rounded-22 object-cover">
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>


  <div class="dashboard" data-x="dashboard" data-x-toggle="-is-sidebar-open">
    <?php include "navbar.php"; ?>

    <div class="dashboard__main">
      <div class="dashboard__content">
        <div class="row y-gap-20 justify-between items-end pb-20 lg:pb-40 md:pb-32">
          <div class="col-auto">

            <h1 class="text-30 lh-14 fw-600">Applicants</h1>
            <!-- <div class="text-15 text-light-1">Lorem ipsum dolor sit amet, consectetur.</div> -->

          </div>

          <div class="col-auto">

          </div>
        </div>


        <div class="py-30 px-30 rounded-4 bg-white custom_shadow">
          <div class="tabs -underline-2 js-tabs">
            <div class="tabs__controls row x-gap-40 y-gap-10 lg:x-gap-20 js-tabs-controls">

              <div class="col-auto">
                <button
                  class="tabs__button text-18 lg:text-16 text-light-1 fw-500 pb-5 lg:pb-0 js-tabs-button is-tab-el-active"
                  data-tab-target=".-tab-item-1">applicants</button>
              </div>


            </div>

            <div class="tabs__content pt-30 js-tabs-content">
            <?php
                    $sql = "SELECT * FROM applicants";
                    $result = $connect->query($sql);
                    $i = 0;
                    while ($row = $result->fetch_assoc()) {
                      $i = $i + 1;

                      $id=$row["id"];
                      $f_name = $row["f_name"];
                      $l_name = $row["l_name"];
                      $dob = $row["dob"];
                      $age = $row["age"];
                      $gender = $row["gender"];
                      $email = $row["email"];
                      $mobile = $row["mobile"];
                      $degree = $row["degree"];
                      $location = $row["location"];
                      $comments = $row["comments"];
                      $resume = $row["resume"];

                      ?>  
              <div class="tabs__pane -tab-item-1 is-tab-el-active">
                <div class="cruise_search_result_wrapper">
                  <div class="cruise_search_item">
                
                  <div class="row">
                    
                      <div class="col-lg-3">
                        <div class="cruise_item_img">
                          <img src="img/dashboard/common/hotel-1.png" alt="img">
                        </div>
                      </div>
                      <div class="col-lg-9">
                        <div class="cruise_item_inner_content">
                          <div class="cruise_content_top_wrapper">
                            <div class="cruise_content_top_left">
                              <ul>
                                <!-- <li>7 nights 8 days tour <i class="fas fa-circle"></i></li> -->
                                <li>Family tour</li>
                              </ul>
                              <h4>Explore the ancient china</h4>
                              <p><i class="fas fa-map-marker-alt"></i> Beijing, China</p>
                            </div>
                            <div class="cruise_content_top_right">
                              <h5>4.8/5 Excellent</h5>
                              <h4>(1214 reviewes)</h4>
                            </div>
                          </div>
                          <div class="cruise_content_middel_wrapper">
                            <div class="cruise_content_middel_left">
                              <h5>Free cancellation</h5>
                              <p>Cancel your booking at any time</p>
                            </div>
                            <div class="cruise_content_middel_right">
                              <h3>$99.00 <sub>/Per person</sub></h3>
                              <p>+ $20.00 tax and vat</p>
                            </div>
                          </div>
                          <div class="cruise_content_bottom_wrapper">
                            <div class="cruise_content_bottom_left">
                              <ul>
                                <li>Breakfast</li>
                                <li>Free wi fi</li>
                                <li>Transport</li>
                                <li>Gym</li>
                              </ul>
                            </div>
                            <div class="cruise_content_bottom_right">
                              <a href="#!" class="button h-50 px-24 -dark-1 bg-blue-1 text-white">View details</a>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                    </div>
                   
                  </div>
                 
                </div>
               
              </div>
              <?php } ?>

            
            </div>
          </div>

          
        </div>


   <!-- footer start -->
   <?php include "footer.php"; ?>
   <!-- footer end -->
      </div>
    </div>
  </div>

  <!-- JavaScript -->
<?php include "footer_script.php"; ?>

</body>

</html>