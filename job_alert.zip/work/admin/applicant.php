<?php include "config.php";
session_start();
if (!isset($_SESSION["username"])) {
  header("Location:login.php?mes=login_error");
} else {
  $username = $_SESSION["username"];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "header.php"; ?>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.2.3/css/fixedHeader.dataTables.min.css">

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/fixedheader/3.2.3/js/dataTables.fixedHeader.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<body data-barba="wrapper">


  <div class="preloader js-preloader">

  </div>


  <div class="header-margin"></div>
  <header data-add-bg="" class="header -dashboard bg-white js-header" data-x="header" data-x-toggle="is-menu-opened">
    <div data-anim="fade" class="header__container px-30 sm:px-20">
      <div class="-left-side">
        <a href="#!" class="header-logo" data-x="header-logo" data-x-toggle="is-logo-dark">
          <img src="img/general/logo.png" alt="logo icon">
          <img src="img/general/logo.png" alt="logo icon">
        </a>
      </div>

      <div class="row justify-between items-center pl-60 lg:pl-20">
        <div class="col-auto">
          <div class="d-flex items-center">
            <button data-x-click="dashboard">
              <i class="icon-menu-2 text-20"></i>
            </button>

            <div class="single-field relative d-flex items-center md:d-none ml-30">
              <input class="pl-50 border-light text-dark-1 h-50 rounded-8" type="email" placeholder="Search">
              <button class="absolute d-flex items-center h-full">
                <i class="icon-search text-20 px-15 text-dark-1"></i>
              </button>
            </div>
          </div>
        </div>

        <div class="col-auto">
          <div class="d-flex items-center">

            <div class="pl-15">
              <img src="img/avatars/3.png" alt="image" class="size-50 rounded-22 object-cover">
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>


  <div class="dashboard" data-x="dashboard" data-x-toggle="-is-sidebar-open">
    <?php include "navbar.php"; ?>

    <div class="dashboard__main">
      <div class="dashboard__content">
        <div class="row y-gap-20 justify-between items-end pb-20 lg:pb-40 md:pb-32">
          <div class="col-auto">

          <h1 class="text-30 lh-14 fw-600">Applicant Details</h1>
          </div>

          <div class="col-auto">
          </div>
        </div>


        <div class="py-30 px-30 rounded-4 bg-white custom_shadow">
          <div class="tabs -underline-2 js-tabs">
            <div class="tabs__controls row x-gap-40 y-gap-10 lg:x-gap-20 js-tabs-controls">

              <div class="col-auto">
              </div>

            </div>

            <div class="tabs__content pt-30 js-tabs-content table_action_icon">

              <div class="tabs__pane -tab-item-1 is-tab-el-active">
                <div class="overflow-scroll scroll-bar-1">
                  <table  id="example" class="table-3 -border-bottom col-12">
                    <thead class="bg-light-2">
                      <tr>
                        <th>S.No</th>
                        <th>Name</th>
                        <th>Dob</th>
                        <th>Age</th>
                        <th>Gender</th>                       
                        <th>Email</th>
                        <th>Mobile</th> 
                        <th>Qualification</th>                       
                        <th>Location</th>
                        <th>Message</th>
                        <th>Resume</th>                        
                        <th>view</th>
                        <th>Delete</th>
                      </tr>
                    </thead>
                    <?php
                    $sql = "SELECT * FROM applicant";
                    $result = $connect->query($sql);
                    $i = 0;
                    while ($row = $result->fetch_assoc()) {
                      $i = $i + 1;

                      $id=$row["id"];
                      $f_name = $row["f_name"];
                      $l_name = $row["l_name"];
                      $dob = $row["dob"];
                      $age = $row["age"];
                      $gender = $row["gender"];
                      $email = $row["email"];
                      $mobile = $row["mobile"];
                      $degree = $row["degree"];
                      $location = $row["location"];
                      $comments = $row["comments"];
                      $resume = $row["resume"];

                      ?>
                  
                      <tbody>

                      <tr>
                        <td><?php echo "$id"; ?></td>
                        <td><?php echo "$f_name.$l_name"; ?></td>
                        <td><?php echo "$dob"; ?></td>
                        <td><?php echo "$age"; ?></td>
                        <td><?php echo "$gender"; ?></td>
                        <td><?php echo "$email"; ?></td>
                        <td><?php echo "$mobile"; ?></td>
                        <td><?php echo "$degree"; ?></td>
                        <td><?php echo "$location"; ?></td>
                        <td><?php echo "$comments"; ?></td>
                        
                        <td><a href="../job/upload/resume/<?php echo "$resume"; ?>">view Resume </a></td>
                        <td><?php  ?></td>
                        <td><a href="applicant.php?delete_id=<?php echo $id; ?>">delete</a></td>
                    </tr>
                    <?php } ?>

                      </tbody>
                  </table>
                  <?php
                  if (isset($_GET["delete_id"])) {
                    $delete_id = $_GET["delete_id"];
                    $sql = "DELETE FROM applicant where id='$delete_id'";
                    if ($connect->query($sql)) {
                      echo "<script>alert('Deleted Successfully');
                window.location.replace('applicant.php')</script>";
                    } else {
                      echo "<script>alert('Not Deleted');
                window.location.replace('applicant.php')</script>";
                    }
                  }
                  ?>
                 
            
                </div>
              </div>
            </div>
          </div>

        </div>

        <script>
                $(document).ready(function() {
                    $('#example thead tr')
                        .clone(true)
                        .addClass('filters')
                        .appendTo('#example thead');

                    var table = $('#example').DataTable({
                        orderCellsTop: true,
                        fixedHeader: true,
                        initComplete: function() {
                            var api = this.api();
                            api
                                .columns()
                                .eq(0)
                                .each(function(colIdx) {
                                    var cell = $('.filters th').eq(
                                        $(api.column(colIdx).header()).index()
                                    );
                                    var title = $(cell).text();
                                    $(cell).html('<input type="text" placeholder="' + title + '" />');
                                    $(
                                            'input',
                                            $('.filters th').eq($(api.column(colIdx).header()).index())
                                        )
                                        .off('keyup change')
                                        .on('change', function(e) {
                                            $(this).attr('title', $(this).val());
                                            var regexr = '({search})';
                                            var cursorPosition = this.selectionStart;
                                            api
                                                .column(colIdx)
                                                .search(
                                                    this.value != '' ?
                                                    regexr.replace('{search}', '(((' + this.value + ')))') :
                                                    '',
                                                    this.value != '',
                                                    this.value == ''
                                                )
                                                .draw();
                                        })
                                        .on('keyup', function(e) {
                                            e.stopPropagation();

                                            $(this).trigger('change');
                                            $(this)
                                                .focus()[0]
                                                .setSelectionRange(cursorPosition, cursorPosition);
                                        });
                                });
                        },
                    });
                });
            </script>


        <!-- footer start -->
        <?php include "footer.php"; ?>
        <!-- footer end -->
      </div>
    </div>
  </div>

  <?php include "footer_script.php"; ?>
</body>

</html>