<?php include "config.php"; ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "header.php"; ?>
</head>

<body data-barba="wrapper">


  <div class="preloader js-preloader">

  </div>


  <div class="header-margin"></div>
  <header data-add-bg="" class="header -dashboard bg-white js-header" data-x="header" data-x-toggle="is-menu-opened">
    <div data-anim="fade" class="header__container px-30 sm:px-20">
      <div class="-left-side">
        <a href="#!" class="header-logo" data-x="header-logo" data-x-toggle="is-logo-dark">
          <img src="img/general/logo.png" alt="logo icon">
          <img src="img/general/logo.png" alt="logo icon">
        </a>
      </div>

      <div class="row justify-between items-center pl-60 lg:pl-20">
        <div class="col-auto">
          <div class="d-flex items-center">
            <button data-x-click="dashboard">
              <i class="icon-menu-2 text-20"></i>
            </button>

            <div class="single-field relative d-flex items-center md:d-none ml-30">
              <input class="pl-50 border-light text-dark-1 h-50 rounded-8" type="email" placeholder="Search">
              <button class="absolute d-flex items-center h-full">
                <i class="icon-search text-20 px-15 text-dark-1"></i>
              </button>
            </div>
          </div>
        </div>

        <div class="col-auto">
          <div class="d-flex items-center">
            <div class="row items-center x-gap-5 y-gap-20 pl-20 lg:d-none">
              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-email-2 text-20"></i>
                </button>
              </div>

              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-notification text-20"></i>
                </button>
              </div>
            </div>

            <div class="pl-15">
              <img src="img/avatars/3.png" alt="image" class="size-50 rounded-22 object-cover">
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>


  <div class="dashboard" data-x="dashboard" data-x-toggle="-is-sidebar-open">
    <div class="dashboard__sidebar bg-white scroll-bar-1">
      <?php include "navbar.php"; ?>
    </div>

    <div class="dashboard__main">
      <div class="dashboard__content">
        <div class="row y-gap-20 justify-between items-end pb-20 lg:pb-40 md:pb-32">
          <div class="col-auto">

            <h1 class="text-30 lh-14 fw-600">Add Vacancy</h1>
            <!-- <div class="text-15 text-light-1">Lorem ipsum dolor sit amet, consectetur.</div> -->

          </div>

          <div class="col-auto">

          </div>
        </div>


        <div class="py-30 px-30 rounded-4 bg-white custom_shadow">
          <div class="tabs -underline-2 js-tabs">
            <div class="tabs__controls row x-gap-40 y-gap-10 lg:x-gap-20 js-tabs-controls">

              <div class="col-auto">
                <button class="tabs__button text-18 lg:text-16 text-light-1 fw-500 pb-5 lg:pb-0 js-tabs-button is-tab-el-active" data-tab-target=".-tab-item-1">Vacancy</button>
              </div>


            </div>

            <div class="tabs__content pt-30 js-tabs-content">
              <div class="tabs__pane -tab-item-1 is-tab-el-active">
                <div class="col-xl-10">
                  <div class="border-top-light mt-30 mb-30"></div>
                  <!-- form start -->
                  <div class="container">
                    <form action="" method="POST" enctype="multipart/form-data">
                      <div class="row x-gap-20 y-gap-20">
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Title</label>
                            <input type="text" name="job_title" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Type</label>
                            <!-- <input type="text" name="job_type" > -->
                            <select class="form-control input-sm" name="job_type">
                              <option value="">Select</option>
                              <option value="full time">full time</option>
                              <option value="part time">Part time</option>
                              <option value="intern">Intern</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Company Name</label>
                            <!-- <input type="text" name="company_name" > -->
                            <select class="form-control input-sm" name="company_name">
                            <?php
                            
                        echo "<option value=''>Select</option>";
                        $sql = "SELECT * from company";
                        $res = $connect->query($sql);
                        while ($row = $res->fetch_assoc()) {
                            $company_name = $row["company_name"];
                            echo "<option value='$company_name'>$company_name</option>";
                        }

                        ?>
                        </select>
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Company_mobile</label>
                            <!-- <input type="text" name="company_mobile" > -->
                            <select class="form-control input-sm" name="company_mobile">
                            <?php
                        echo "<option value=''>Select</option>";
                        $sql = "SELECT * from company";
                        $res = $connect->query($sql);
                        while ($row = $res->fetch_assoc()) {
                            $company_mobile = $row["company_mobile"];
                            echo "<option value='$company_mobile'>$company_mobile</option>";
                        }

                        ?>
                        </select>
                          </div>
                        </div>

                        <!-- <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Mobile number</label>
                            <input type="text" name="mobile" >
                          </div>
                        </div> -->
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Email</label>
                            <input type="text" name="email" >
                          </div>
                        </div>
                      
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">No Of Openings</label>
                            <input type="text" name="no_of_openings" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Qualification</label>
                            <input type="text" name="qualification" >
                          </div>
                        </div>

                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Location</label>
                            <input type="text" name="job_location" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job District</label>
                            <input type="text" name="job_district" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Description</label>
                            <input type="text" name="job_description" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Experience</label>
                            <input type="text" name="experience" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Skills</label>
                            <input type="text" name="skills" >
                          </div>
                        </div>

                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">salary</label>
                            <input type="text" name="salary" >
                          </div>
                        </div>
                        <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Job Category</label>
                            <input type="text" name="job_category" >
                          </div>
                        </div>


                        </div>

                        <!-- <div class="col-6">
                          <div class="form-input ">
                            <label class="lh-1 text-16 text-light-1">Profile</label>
                            <input type="file" name="photo" >
                          </div>
                        </div> -->

                      </div>
                      <button class="btn btn-info mt-4" type="submit" name="submit">save</button>
                    </form>
                    <?php
                    if (isset($_POST["submit"])) {
                      $job_title = $_POST["job_title"];
                      $job_type = $_POST["job_type"];
                      $company_name = $_POST["company_name"];
                      // $mobile = $_POST["mobile"];
                      $email = $_POST["email"];
                      $company_mobile = $_POST["company_mobile"];
                      $no_of_openings = $_POST["no_of_openings"];
                      $qualification = $_POST["qualification"];
                      $job_location = $_POST["job_location"];
                      $job_district = $_POST["job_district"];
                      $job_description = $_POST["job_description"];
                      $experience=$_POST["experience"];
                      $skills=$_POST["skills"];
                      $salary=$_POST["salary"];
                      $job_category=$_POST["job_category"];

                      // $temp = explode(".", $_FILES["photo"]["name"]); //file name get
                      // $photo = "photo$mobile." . end($temp);      //file name rename to photo and mobile no
                      // move_uploaded_file($_FILES["photo"]["tmp_name"], "upload/photo/$photo"); //file uplode 
  

                      $sql = "INSERT INTO vacancy(id, job_title, job_type, company_name, email, company_mobile, no_of_openings, qualification, job_location, job_district, job_description, experience, skills, salary, job_category) VALUES (null, '$job_title', '$job_type', '$company_name', '$email', '$company_mobile', '$no_of_openings', '$qualification', '$job_location', '$job_district', '$job_description', '$experience','$skills', '$salary', '$job_category')";

                      // $sql="INSERT INTO vacancy(id, company_name, mobile, email, password, street, location, district, taluga, pincode, profile) VALUES(null, '$company_name', '$mobile', '$email', '$password', '$street', '$location', '$district', '$taluga', '$pincode', '$profile')";

                      if ($connect->query($sql)) {
                        echo "<script> alert('Vacancy add successfully'); window.location.replace('vacancy.php');</script>";
                      } else {
                        echo "<script> alert('Vacancy add failed'); window.location.replace('addvacancy.php');</script>";
                      }
                    }
                    ?>

                    <!-- form end -->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>



        <?php include "footer.php"; ?>
      </div>
    </div>
  </div>

  <?php include "footer_script.php"; ?>
</body>

</html>