<?php 
$connect=new mysqli("localhost", "root", "", "uibo_job");
?>