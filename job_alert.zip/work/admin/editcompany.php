<?php include "config.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "header.php"; ?>
</head>

<body data-barba="wrapper">


  <div class="preloader js-preloader">

  </div>


  <div class="header-margin"></div>
  <header data-add-bg="" class="header -dashboard bg-white js-header" data-x="header" data-x-toggle="is-menu-opened">
    <div data-anim="fade" class="header__container px-30 sm:px-20">
      <div class="-left-side">
        <a href="#!" class="header-logo" data-x="header-logo" data-x-toggle="is-logo-dark">
          <img src="img/general/logo.png" alt="logo icon">
          <img src="img/general/logo.png" alt="logo icon">
        </a>
      </div>

      <div class="row justify-between items-center pl-60 lg:pl-20">
        <div class="col-auto">
          <div class="d-flex items-center">
            <button data-x-click="dashboard">
              <i class="icon-menu-2 text-20"></i>
            </button>

            <div class="single-field relative d-flex items-center md:d-none ml-30">
              <input class="pl-50 border-light text-dark-1 h-50 rounded-8" type="email" placeholder="Search">
              <button class="absolute d-flex items-center h-full">
                <i class="icon-search text-20 px-15 text-dark-1"></i>
              </button>
            </div>
          </div>
        </div>

        <div class="col-auto">
          <div class="d-flex items-center">
            <div class="row items-center x-gap-5 y-gap-20 pl-20 lg:d-none">
              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-email-2 text-20"></i>
                </button>
              </div>

              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-notification text-20"></i>
                </button>
              </div>
            </div>

            <div class="pl-15">
              <img src="img/avatars/3.png" alt="image" class="size-50 rounded-22 object-cover">
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>


  <div class="dashboard" data-x="dashboard" data-x-toggle="-is-sidebar-open">
    <div class="dashboard__sidebar bg-white scroll-bar-1">
      <?php include "navbar.php"; ?>
    </div>

    <div class="dashboard__main">
      <div class="dashboard__content">
        <div class="row y-gap-20 justify-between items-end pb-20 lg:pb-40 md:pb-32">
          <div class="col-auto">

            <h1 class="text-30 lh-14 fw-600">Edit Company</h1>
            <!-- <div class="text-15 text-light-1">Company Details</div> -->

          </div>

          <div class="col-auto">

          </div>
        </div>


        <div class="py-30 px-30 rounded-4 bg-white custom_shadow">
          <div class="tabs -underline-2 js-tabs">
            <div class="tabs__controls row x-gap-40 y-gap-10 lg:x-gap-20 js-tabs-controls">

              <div class="col-auto">
                <button class="tabs__button text-18 lg:text-16 text-light-1 fw-500 pb-5 lg:pb-0 js-tabs-button is-tab-el-active" data-tab-target=".-tab-item-1">Company</button>
              </div>
            </div>

            <div class="tabs__content pt-30 js-tabs-content">
              <div class="tabs__pane -tab-item-1 is-tab-el-active">
                <div class="col-xl-10">
                  <div class="border-top-light mt-30 mb-30"></div>
                 
                    <div class="container">
                    <?php
                  if (isset($_GET["edit_id"])) {
                    $edit_id = $_GET["edit_id"];
                    $sql = "SELECT * FROM company WHERE id='$edit_id'";
                    $res = $connect->query($sql);
                    while($row = $res->fetch_assoc()){

                      
                    $id=$row["id"];
                    $company_name = $row["company_name"];
                    $company_mobile = $row["company_mobile"];
                    $email = $row["email"];
                    $password = $row["password"];
                    $street = $row["street"];
                    $location = $row["location"];
                    $district = $row["district"];
                    $taluga = $row["taluga"];
                    $pincode = $row["pincode"];
                    // $profile = $row["profile"];
                    $photo=$row["photo"];
                    }
                  ?>

                      <form method="POST" enctype="multipart/form-data">
                        <div class="row x-gap-20 y-gap-20">

                          <div class="col-6">
                            <div class="form-input ">
                              <label class="lh-1 text-16 text-light-1">Company Name</label>
                              <input type="text" name="company_name" value="<?php echo "$company_name"; ?>" >
                            </div>
                          </div>
                          <div class="col-6">
                            <div class="form-input ">
                              <label class="lh-1 text-16 text-light-1">Mobile Number</label>
                              <input type="text" name="company_mobile" value="<?php echo "$company_mobile"; ?>" >
                            </div>
                          </div>
                          <div class="col-6">
                            <div class="form-input ">
                              <label class="lh-1 text-16 text-light-1">Email address</label>
                              <input type="email" name="email" value="<?php echo "$email"; ?>" >
                            </div>
                          </div>
                          <div class="col-6">
                            <div class="form-input ">
                              <label class="lh-1 text-16 text-light-1">Password</label>
                              <input type="text" name="password" value="<?php echo "$password"; ?>" >
                            </div>
                          </div>
                          <div class="col-6">
                            <div class="form-input ">
                              <label class="lh-1 text-16 text-light-1">Street</label>
                              <input type="text" name="street" value="<?php echo "$street"; ?>" >
                            </div>
                          </div>
                          <div class="col-6">
                            <div class="form-input ">
                              <label class="lh-1 text-16 text-light-1">Location</label>
                              <input type="text" name="location" value="<?php echo "$location"; ?>" >
                            </div>
                          </div>
                          <div class="col-6">
                            <div class="form-input ">
                              <label class="lh-1 text-16 text-light-1">district</label>
                              <input type="text" name="district" value="<?php echo "$district"; ?>" >
                            </div>
                          </div>
                          <div class="col-6">
                            <div class="form-input ">
                              <label class="lh-1 text-16 text-light-1">Taluga</label>
                              <input type="text" name="taluga" value="<?php echo "$taluga"; ?>" >
                            </div>
                          </div>
                          <div class="col-6">
                            <div class="form-input ">
                              <label class="lh-1 text-16 text-light-1">Pincode</label>
                              <input type="text" name="pincode" value="<?php echo "$pincode"; ?>" >
                            </div>
                          </div>
                          
                          </div>
                          <button class="btn btn-info mt-4" type="submit" name="submit">update</button>

                        </div>
                  </form>
                  <?php  } ?>
                       <?php 
                      if (isset($_POST["submit"])) {
                        $company_name = $_POST["company_name"];
                        $company_mobile = $_POST["company_mobile"];
                        $email = $_POST["email"];
                        $password = $_POST["password"];
                        $street = $_POST["street"];
                        $location = $_POST["location"];
                        $district = $_POST["district"];
                        $taluga = $_POST["taluga"];
                        $pincode = $_POST["pincode"];
                        // $profile = $_POST["profile"];

                        // $temp = explode(".", $_FILES["profile"]["name"]); //file name get
                        // $profile = "profile$mobile." . end($temp);      //file name rename to photo and mobile no
                        // move_uploaded_file($_FILES["profile"]["tmp_name"], "upload/$profile"); //file uplode 


                        $sql = "UPDATE company SET company_name='$company_name', company_mobile='$company_mobile', email='$email', password='$password', street='$street', location='$location', district='$district', taluga='$taluga', pincode='$pincode' WHERE id='$id' ";

                        if ($connect->query($sql)) {
                          echo "<script> alert('company Update successfully'); window.location.replace('editcompany.php?edit_id=$id');</script>";
                        } else {
                          echo "<script> alert('company Update failed'); window.location.replace('editcompany.php');</script>";
                        }
                      }
                      ?>

                    </div>
                    <hr>
                    <?php
                  if (isset($_GET["edit_id"])) {
                    $edit_id = $_GET["edit_id"];
                    $sql = "SELECT * FROM company WHERE id='$edit_id'";
                    $res = $connect->query($sql);
                    $row = $res->fetch_assoc();

                    $id=$row["id"];
                    $photo=$row["photo"];

                    ?>

                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="col-6">
                              <div class="form-input ">
                                <label class="lh-1 text-16 text-light-1">profile</label>
                                <input type="file" name="photo">
                                <img src="../job/upload/photo/<?php echo "$photo"; ?>">
                              </div>
                            </div>
                            <button class="btn btn-info" type="submit" name="submit1">Update</button>

                    </form>
                    <?php 
                    if(isset($_POST["submit1"])){
                      // $photo=$_POST["photo"];

                       $temp = explode(".", $_FILES["photo"]["name"]); //file name get
                        $photo = "photo$company_mobile." . end($temp);      //file name rename to photo and mobile no
                        move_uploaded_file($_FILES["photo"]["tmp_name"], "../job/upload/photo/$photo"); //file uplode 


                      $sql="UPDATE company SET photo='$photo' WHERE id='$id'";
                      if ($connect->query($sql)) {
                        echo "<script> alert('company add successfully'); window.location.replace('company.php');</script>";
                      } else {
                        echo "<script> alert('company add failed'); window.location.replace('addcompany.php');</script>";
                      }
                      

                    }
                    ?>

                  <?php } ?>

                </div>

              </div>
            </div>
          </div>


          <?php include "footer.php"; ?>
        </div>
      </div>
    </div>

    <?php include "footer_script.php"; ?>
</body>

</html>