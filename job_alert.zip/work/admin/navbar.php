<div class="dashboard__sidebar bg-white scroll-bar-1">
      <div class="sidebar -dashboard">
        <div class="sidebar__item">
          <div class="sidebar__button">
            <a href="index.php" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-border-all mr-15"></i>
              Dashboard
            </a>
          </div>
        </div>
        <div class="sidebar__item">
          <div class="sidebar__button -is-active">
            <a href="company.php" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-cart-plus mr-15"></i>
             Company
            </a>
          </div>
        </div>

        <div class="sidebar__item">
          <div class="sidebar__button -is-active">
            <a href="vacancy.php" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-cart-plus mr-15"></i>
             vacancy
            </a>
          </div>
        </div>

        <div class="sidebar__item">
          <div class="sidebar__button -is-active">
            <a href="user.php" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-cart-plus mr-15"></i>
             User
            </a>
          </div>
        </div>
        <div class="sidebar__item">
          <div class="sidebar__button -is-active">
            <a href="applicant.php" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-cart-plus mr-15"></i>
             Applicants
            </a>
          </div>
        </div>

        <!-- <div class="sidebar__item ">
          <div class="accordion -db-sidebar js-accordion">
            <div class="accordion__item">
              <div class="accordion__button">
                <div class="sidebar__button col-12 d-flex items-center justify-between">
                  <div class="d-flex items-center text-15 lh-1 fw-500">
                    <i class="fas fa-building mr-15"></i>
                    Manage Hotel
                  </div>
                  <div class="icon-chevron-sm-down text-7"></div>
                </div>
              </div>

              <div class="accordion__content">
                <ul class="list-disc pb-5 pl-40">

                  <li>
                    <a href="db-vendor-hotels.html" class="text-15">All hotels</a>
                  </li>

                  <li>
                    <a href="db-vendor-add-hotel.html" class="text-15">Add hotel</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="sidebar__item ">
          <div class="accordion -db-sidebar js-accordion">
            <div class="accordion__item">
              <div class="accordion__button">
                <div class="sidebar__button col-12 d-flex items-center justify-between">
                  <div class="d-flex items-center text-15 lh-1 fw-500">
                    <i class="fas fa-flag  mr-15"></i>
                    Manage tour
                  </div>
                  <div class="icon-chevron-sm-down text-7"></div>
                </div>
              </div>

              <div class="accordion__content">
                <ul class="list-disc pb-5 pl-40">

                  <li>
                    <a href="db-vendor-tour.html" class="text-15">All tour</a>
                  </li>

                  <li>
                    <a href="db-vendor-add-tour.html" class="text-15">Add tour</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="sidebar__item ">
          <div class="accordion -db-sidebar js-accordion">
            <div class="accordion__item">
              <div class="accordion__button">
                <div class="sidebar__button col-12 d-flex items-center justify-between">
                  <div class="d-flex items-center text-15 lh-1 fw-500">
                    <i class="fas fa-bus-alt mr-15"></i>
                    Manage bus
                  </div>
                  <div class="icon-chevron-sm-down text-7"></div>
                </div>
              </div>

              <div class="accordion__content">
                <ul class="list-disc pb-5 pl-40">

                  <li>
                    <a href="db-vendor-bus.html" class="text-15">All bus</a>
                  </li>

                  <li>
                    <a href="db-vendor-add-bus.html" class="text-15">Add bus</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div class="sidebar__item">
          <div class="sidebar__button">
            <a href="db-wishlist.html" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-tags mr-15"></i>
              Wishlist
            </a>
          </div>
        </div>

        <div class="sidebar__item">
          <div class="sidebar__button ">
            <a href="db-profile.html" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-user-circle  mr-15"></i>
              My profile
            </a>
          </div>
        </div>
        <div class="sidebar__item">
          <div class="sidebar__button ">
            <a href="db-notification.html" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-wallet mr-15"></i>
              Notification
            </a>
          </div>
        </div>
        <div class="sidebar__item">
          <div class="sidebar__button ">
            <a href="db-settings.html" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-cog mr-15"></i>
              Settings
            </a>
          </div>
        </div> -->

        <div class="sidebar__item">
          <div class="sidebar__button ">
            <a href="logout.php" class="d-flex items-center text-15 lh-1 fw-500">
              <i class="fas fa-sign-out-alt mr-15"></i>
              Logout
            </a>
          </div>
        </div>
      </div>
    </div>