<?php include "config.php";
session_start();
if (!isset($_SESSION["username"])) {
  header("Location:login.php?mes=login_error");
} else {
  $username = $_SESSION["username"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php include "header.php"; ?>
</head>

<body data-barba="wrapper">

  <div class="preloader js-preloader">

  </div>


  <div class="header-margin"></div>
  <header data-add-bg="" class="header -dashboard bg-white js-header" data-x="header" data-x-toggle="is-menu-opened">
    <div data-anim="fade" class="header__container px-30 sm:px-20">
      <div class="-left-side">
      </div>

      <div class="row justify-between items-center pl-60 lg:pl-20">
        <div class="col-auto">
          <div class="d-flex items-center">
            <button data-x-click="dashboard">
              <i class="icon-menu-2 text-20"></i>
            </button>

            <div class="single-field relative d-flex items-center md:d-none ml-30">
              <input class="pl-50 border-light text-dark-1 h-50 rounded-8" type="email" placeholder="Search">
              <button class="absolute d-flex items-center h-full">
                <i class="icon-search text-20 px-15 text-dark-1"></i>
              </button>
            </div>
          </div>
        </div>

        <div class="col-auto">
          <div class="d-flex items-center">
            <div class="row items-center x-gap-5 y-gap-20 pl-20 lg:d-none">
              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-email-2 text-20"></i>
                </button>
              </div>

              <div class="col-auto">
                <button class="button -blue-1-05 size-50 rounded-22 flex-center">
                  <i class="icon-notification text-20"></i>
                </button>
              </div>
            </div>

            <div class="pl-15">
              <img src="img/avatars/3.png" alt="image" class="size-50 rounded-22 object-cover">
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>


  <div class="dashboard" data-x="dashboard" data-x-toggle="-is-sidebar-open">
    <div class="dashboard__sidebar bg-white scroll-bar-1">
      <?php include "navbar.php"; ?>
    </div>

    <div class="dashboard__main">
      <div class="dashboard__content">
        <div class="row y-gap-20 justify-between items-end pb-20 lg:pb-40 md:pb-32">
          <div class="col-auto">
            <h1 class="text-30 lh-14 fw-500">Dashboard</h1>
            <div class="text-15 text-light-1">Lorem ipsum dolor sit amet, consectetur.</div>
          </div>

          <div class="col-auto">

          </div>
        </div>

        <div class="row y-gap-30">
          <div class="col-xl-3 col-md-6 col-sm-6 col-12">
            <div class="py-15 px-15 custom_border_left_blue custom_rounded bg-white custom_shadow">
              <div class="row y-gap-20 justify-between items-center">
                <div class="col-md-6">
                  <div class="fw-500 lh-14">Total Company</div>
                            <?php
                            $sql = "SELECT * FROM company";
                            $res = $connect->query($sql);
                            $id = $res->num_rows;

                            ?>
                  <div class="text-30 lh-16 fw-600 mt-5 text_blue"><?php echo "$id"; ?></div>
                 
                </div>

                <div class="col-md-6">
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 col-sm-6 col-12">
            <div class="py-15 px-30 custom_border_left_oreng custom_rounded bg-white custom_shadow">
              <div class="row y-gap-20 justify-between items-center">
                <div class="col-md-6">
                  <div class="fw-500 lh-14">Total Vacancy</div>
                  <?php
                            $sql = "SELECT * FROM vacancy";
                            $res = $connect->query($sql);
                            $id = $res->num_rows;

                            ?>

                  <div class="text-30 lh-16 fw-600 mt-5 text_oreng"><?php echo "$id"; ?></div>
                </div>

                <div class="col-md-6">
                  <img src="img/dashboard/icons/arrow-2.png" alt="icon">
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 col-sm-6 col-12">
            <div class="py-15 px-30 custom_border_left_sky custom_rounded bg-white custom_shadow">
              <div class="row y-gap-20 justify-between items-center">
                <div class="col-md-6">
                  <div class="fw-500 lh-14">Total Users</div>
                  <?php
                            $sql = "SELECT * FROM user";
                            $res = $connect->query($sql);
                            $id = $res->num_rows;

                            ?>

                  <div class="text-30 lh-16 fw-600 mt-5 text_sky"><?php echo "$id"; ?></div>
                </div>

                <div class="col-md-6">
                  <img src="img/dashboard/icons/arrow-3.png" alt="icon">
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 col-sm-6 col-12">
            <div class="py-15 px-30 custom_border_left_green custom_rounded bg-white custom_shadow">
              <div class="row y-gap-20 justify-between items-center">
                <div class="col-md-6">
                  <div class="fw-500 lh-14">Total services</div>
                  <div class="text-30 lh-16 fw-600 mt-5 text_green">22,786</div>
                  <div class="text-15 lh-14 text-light-1 mt-5 text_green">(+2.35%) <span><i class="fas fa-arrow-up"></i></span></div>
                </div>

                <div class="col-md-6">
                  <img src="img/dashboard/icons/arrow-4.png" alt="icon">
                </div>
              </div>
            </div>
          </div>

        </div>

        <div class="row y-gap-30 pt-20">
          <div class="col-xl-6 col-md-6">
            <div class="py-30 px-30 custom_rounded bg-white custom_shadow">
              <div class="d-flex justify-between items-center heading_border">
                <h2 class="text-18 lh-1 fw-500">
                  Expense overview
                </h2>
              </div>

              <div class="pt-30">
                <canvas id="lineChart"></canvas>
              </div>
            </div>
          </div>

          <div class="col-xl-6 col-md-6">
            <div class="py-30 px-30 rounded-4 bg-white custom_shadow">
              <div class="d-flex justify-between items-center heading_border">
                <h2 class="text-18 lh-1 fw-500">
                  My bookings
                </h2>
              </div>

              <div class="overflow-scroll scroll-bar-1 pt-30">
                <table class="table-2 col-12">
                  <thead class="">
                    <tr>
                      <th>Sl no.</th>
                      <th>Booking ID</th>
                      <th>Booking type</th>
                      <th>Booking amount</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>01.</td>
                      <td>#JK589V80</td>
                      <td>Hotel</td>
                      <td>$754.00</td>
                      <td>
                        <div class="text-center col-12 text-14 fw-500 text-yellow-3">Completed</div>
                      </td>
                      <td><i class="fas fa-eye"></i></td>
                    </tr>
                    <tr>
                    <tr>
                      <td>02.</td>
                      <td>#JK589V80</td>
                      <td> Flight</td>
                      <td>$754.00</td>
                      <td>
                        <div class="text-center col-12 text-14 fw-500 text-yellow-3">Completed</div>
                      </td>
                      <td><i class="fas fa-eye"></i></td>
                    </tr>
                    <tr>
                      <td>03.</td>
                      <td>#JK589V80</td>
                      <td>Tour</td>
                      <td>$754.00</td>
                      <td>
                        <div class="text-center col-12 text-14 fw-500 text-yellow-3">Completed</div>
                      </td>
                      <td><i class="fas fa-eye"></i></td>
                    </tr>
                    <tr>
                      <td>04.</td>
                      <td>#JK589V80</td>
                      <td>Flight</td>
                      <td>$754.00</td>
                      <td>
                        <div class="text-center col-12 text-14 fw-500 text-yellow-3">Completed</div>
                      </td>
                      <td><i class="fas fa-eye"></i></td>
                    </tr>
                    <tr>
                      <td>05.</td>
                      <td>#JK589V80</td>
                      <td>Hotel</td>
                      <td>$754.00</td>
                      <td>
                        <div class="text-center col-12 text-14 fw-500 text-red-3">Canceled</div>
                      </td>
                      <td><i class="fas fa-eye"></i></td>
                    </tr>
                    <tr>
                      <td>06.</td>
                      <td>#JK589V80</td>
                      <td>Tour</td>
                      <td>$754.00</td>
                      <td>
                        <div class="text-center col-12 text-14 fw-500 text-yellow-3">Completed</div>
                      </td>
                      <td><i class="fas fa-eye"></i></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <footer class="footer -dashboard mt-60">
          <div class="footer__row row y-gap-10 items-center justify-between">
            <div class="col-auto">
              <div class="row y-gap-20 items-center">
                <div class="col-auto">
                  <div class="text-14 lh-14 mr-30">Copyright © 2022 All Rights Reserved</div>
                </div>
              </div>
            </div>
            <div class="col-auto">
              <div class="d-flex x-gap-5 y-gap-5 items-center">
                <img src="img/avatars/card.png" alt="img">
             </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  </div>

  <!-- JavaScript -->
  <script src="js/chart.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAAz77U5XQuEME6TpftaMdX0bBelQxXRlM"></script>
  <script src="../../../unpkg.com/%40googlemaps/markerclusterer%402.0.13/dist/index.min.html"></script>

  <script src="js/vendors.js"></script>
  <script src="js/main.js"></script>
</body>


</html>
