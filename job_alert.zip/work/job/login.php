<?php
include "config.php";
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Company Reistration </title>
  <?php include "header.php"; ?>

  <style>
    /* all */
    @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap");

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Poppins", sans-serif;
    }

    :root {
      --main-blue: #71b7e6;
      --main-purple: #9b59b6;
      --main-grey: #ccc;
      --sub-grey: #d9d9d9;
    }

    body {
      display: flex;
      height: 100vh;
      justify-content: center;
      /*center vertically */
      align-items: center;
      /* center horizontally */
      /* background: linear-gradient(135deg, var(--main-blue), var(--main-purple)); */
      background-color: #059669;
      padding: 10px;
    }

    /* container and form */
    .container {
      max-width: 700px;
      width: 100%;
      background: #fff;
      padding: 25px 30px;
      border-radius: 5px;
    }

    .container .title {
      font-size: 25px;
      font-weight: 500;
      position: relative;
    }

    .container .title::before {
      content: "";
      position: absolute;
      height: 3.5px;
      width: 30px;
      /* background: linear-gradient(135deg, var(--main-blue), var(--main-purple)); */
      background-color: #059669;
      left: 0;
      bottom: 0;
    }

    .container form .user__details {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      margin: 20px 0 12px 0;
    }

    /* inside the form user details */
    form .user__details .input__box {
      width: calc(100% / 2 - 20px);
      margin-bottom: 15px;
    }

    .user__details .input__box .details {
      font-weight: 500;
      margin-bottom: 5px;
      display: block;
    }

    .user__details .input__box input {
      height: 45px;
      width: 100%;
      outline: none;
      border-radius: 5px;
      border: 1px solid var(--main-grey);
      padding-left: 15px;
      font-size: 16px;
      border-bottom-width: 2px;
      transition: all 0.3s ease;
    }

    .user__details .input__box input:focus,
    .user__details .input__box input:valid {
      border-color: var(--main-purple);
    }

    /* inside the form gender details */

    form .gender__details .gender__title {
      font-size: 20px;
      font-weight: 500;
    }

    form .gender__details .category {
      display: flex;
      width: 80%;
      margin: 15px 0;
      justify-content: space-between;
    }

    .gender__details .category label {
      display: flex;
      align-items: center;
    }

    .gender__details .category .dot {
      height: 18px;
      width: 18px;
      background: var(--sub-grey);
      border-radius: 50%;
      margin: 10px;
      border: 5px solid transparent;
      transition: all 0.3s ease;
    }

    #dot-1:checked~.category .one,
    #dot-2:checked~.category .two,
    #dot-3:checked~.category .three {
      border-color: var(--sub-grey);
      background: var(--main-purple);
      /* background-color: */
    }

    form input[type="radio"] {
      display: none;
    }

    /* submit button */
    form .button {
      height: 45px;
      margin: 45px 0;
    }

    form .button {
      height: 100%;
      width: 100%;
      outline: none;
      color: #fff;
      border: none;
      font-size: 18px;
      font-weight: 500;
      border-radius: 5px;
      /* background: linear-gradient(135deg, var(--main-blue), var(--main-purple)); */
      background-color: #059669;
      transition: all 0.3s ease;
    }

    form .button button:hover {
      /* background: linear-gradient(-135deg, var(--main-blue), var(--main-purple)); */
      background-color: #059669;
    }

    @media only screen and (max-width: 584px) {
      .container {
        max-width: 100%;
      }

      form .user__details .input__box {
        margin-bottom: 15px;
        width: 100%;
      }

      form .gender__details .category {
        width: 100%;
      }

      .container form .user__details {
        max-height: 300px;
        overflow-y: scroll;
      }

      .user__details::-webkit-scrollbar {
        width: 0;
      }
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="title">Company Login</div>
    <form action="#" method="POST">
      <div class="user__details">

        <div class="input__box">
          <span class="details">Mobile Number</span>
          <input type="tel" name="company_mobile" placeholder="Enter Your Mobile Number" required>
        </div>

        <div class="input__box">
          <span class="details">Password</span>
          <input type="password" name="password" placeholder="********" required>
        </div>
      </div>
      <button class="button" type="submit" name="submit">Login</button>
        <div >
          <span class="text-slate-400 me-2"> </span> <a href="register.php" class="text-black dark:text-white font-bold">Register</a>
        </div>
    </form>
  </div>
  <?php
  if (isset($_POST["submit"])) {
    $company_mobile = $_POST["company_mobile"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM company WHERE company_mobile='$company_mobile' AND password='$password'";
    $res = $connect->query($sql);
    if ($row = $res->fetch_assoc()) {
      $_SESSION["company_mobile"] = $row["company_mobile"];
      echo "<script>alert('successfully login');window.location.replace('update_profile.php');</script>";
    } else {
      echo "<script>swal('Invalid Login Credentials');</script>";
    }
  }
  ?>

</body>

</html>