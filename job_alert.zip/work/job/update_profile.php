<?php include "config.php";
session_start();
if (!isset($_SESSION["company_mobile"])) {
    header("Location:login.php");
} else {
    $company_mobile = $_SESSION["company_mobile"];
    // $sql="SELECT * FROM user WHERE mobile='$mobile'";
    // $res=$connect->query($sql);
    // $row=$res->fetch_assoc();
    // $mobile=$row["mobile"];
}
?>

<!DOCTYPE html>
<html lang="en" class="light scroll-smooth" dir="ltr">
 <head>
       <?php include "header.php"; ?>

    </head>
    
    <body class="dark:bg-slate-900">

    <script>

function FindAge(){
    var day = document.getElementById("dob").value;
    var DOB= new Date(day);
    var today= new Date();
    var Age= today.getTime() - DOB.getTime();
    Age = Math.floor(Age / (1000 * 60 * 60 * 24 * 365.25));
    document.getElementById("age").value = Age;
    
}


</script>
        
        <!-- Start Navbar -->
        <?php include "side_nav.php"; ?>
        <!-- End Navbar -->

        <!-- Start Hero -->
        <section class="relative table w-full py-36 bg-[url('')] bg-top bg-no-repeat bg-cover">
            <div class="absolute inset-0 bg-emerald-900/90"></div>
            <div class="container">
                <div class="grid grid-cols-1 text-center mt-10">
                    <h3 class="md:text-3xl text-2xl md:leading-snug tracking-wide leading-snug font-medium text-white">Update Profile</h3>

                </div><!--end grid-->
            </div><!--end container-->
            
            <div class="absolute text-center z-10 bottom-5 start-0 end-0 mx-3">
                <ul class="breadcrumb tracking-[0.5px] breadcrumb-light mb-0 inline-block">
                   <li class="inline breadcrumb-item text-[15px] font-semibold duration-500 ease-in-out text-white/50 hover:text-white"><a href="index.php">uibo job</a></li>
                    <li class="inline breadcrumb-item text-[15px] font-semibold duration-500 ease-in-out text-white" aria-current="page">Update Profile</li>
                </ul>
            </div>
        </section><!--end section-->
        <div class="relative">
            <div class="shape absolute start-0 end-0 sm:-bottom-px -bottom-[2px] overflow-hidden z-1 text-slate-50 dark:text-slate-800">
                <svg class="w-full h-auto" viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div>
        <!-- End Hero -->

        <!-- Start -->
        <section class="relative bg-slate-50 dark:bg-slate-800 lg:py-24 py-16">
            <div class="container">
                <div class="md:flex justify-center">
                    <div class="lg:w-2/4 md:w-2/3">
                    <div class="p-6 bg-white dark:bg-slate-900 shadow dark:shadow-gray-700 rounded-md">
                       
                
                       <?php
                    $sql = "SELECT * FROM company WHERE company_mobile='$company_mobile'";
                    $res = $connect->query($sql);
                    $i = 0;
                    if($row = $res->fetch_assoc()){

                    $i = $i + 1;
                    $id=$row["id"];
                    $company_name = $row["company_name"];
                    $company_mobile = $row["company_mobile"];
                    $email = $row["email"];
                    $password = $row["password"];
                    $street = $row["street"];
                    $location = $row["location"];
                    $district = $row["district"];
                    $taluga = $row["taluga"];
                    $pincode = $row["pincode"];
                    $photo=$row["photo"];  

                    }
                    
                  ?>

                            <form class="text-left" method="POST" enctype="multipart/form-data">
                                <div class="grid grid-cols-1">
                                    <div class="mb-4 ltr:text-left rtl:text-right">
                                        <label for="jobcategories" class="font-semibold">Company Name</label>
                                       
                                        <input  type="text" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="Uibo infotech" name="company_name" value="<?php echo "$company_name"; ?>">
                                    </div>

                                    <div class="mb-4 ltr:text-left rtl:text-right">
                                        <label class="font-semibold" for="RegisterName">Company Mobile</label>
                                        <input id="RegisterName" type="text" class="form-input border border-slate-100 dark:border-slate-800 mt-1" name="company_mobile" value="<?php echo "$company_mobile"; ?>" placeholder="9876543210">
                                    </div>

                                    <div class="mb-4 ltr:text-left rtl:text-right">
                                        <label class="font-semibold" for="LoginEmail">Email Address:</label>
                                        <input  type="email" name="email" value="<?php echo "$email"; ?>" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="uiboinfotech@gmail.com">
                                    </div>

                                    <div class="mb-4 ltr:text-left rtl:text-right">
                                        <label class="font-semibold" >Password</label>
                                        <input type="text" name="password" value="<?php echo "$password"; ?>" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="password">
                                    </div>

                                    <div class="mb-4 ltr:text-left rtl:text-right">
                                        <label for="statename" class="font-semibold">Street:</label>
                                        <input type="text" name="street" value="<?php echo "$street"; ?>" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="Street">
                                    </div>

                                    <div class="mb-4 ltr:text-left rtl:text-right">
                                        <label for="statename" class="font-semibold">Location:</label>
                                        <input type="text" class="form-input border border-slate-100 dark:border-slate-800 mt-1" name="location" value="<?php echo "$location"; ?>" placeholder="Location">
                                        
                                    </div>
                                    <div class="mb-4 ltr:text-left rtl:text-right">
                                        <label for="statename" class="font-semibold">District:</label>
                                        <input  type="text" name="district" value="<?php echo "$district"; ?>" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="District">
                                        
                                    </div>

                                    <div class="mb-4 ltr:text-left rtl:text-right">
                                        <label for="statename" class="font-semibold">Taluga:</label>
                                        <input type="text" name="taluga" value="<?php echo "$taluga"; ?>" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="Taluga">
                                        
                                    </div>
                                    <div class="mb-4 ltr:text-left rtl:text-right">
                                        <label for="statename" class="font-semibold">Pincode:</label>
                                        <input  type="number" name="pincode" value="<?php echo "$pincode"; ?>" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="">
                                        
                                    </div>
                                    <div>
                                        <button type="submit" id="submit" name="send" class="btn rounded-md bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white">Update</button>
                                    </div>
                                </div>
                            </form><!--end form-->
                        
                            <?php 
                            if(isset($_POST["send"])){
                                $company_name = $_POST["company_name"];
                                $company_mobile = $_POST["company_mobile"];
                                $email = $_POST["email"];
                                $password = $_POST["password"];
                                $street = $_POST["street"];
                                $location = $_POST["location"];
                                $district = $_POST["district"];
                                $taluga = $_POST["taluga"];
                                $pincode = $_POST["pincode"];


                        $sql = "UPDATE company SET company_name='$company_name', company_mobile='$company_mobile', email='$email', password='$password', street='$street', location='$location', district='$district', taluga='$taluga', pincode='$pincode' WHERE id='$id' ";

                        if ($connect->query($sql)) {
                          echo "<script> alert('Update successfully'); window.location.replace('update_profile.php');</script>";
                        } else {
                          echo "<script> alert('Update failed'); window.location.replace('update_profile.php');</script>";
                        }
                      }

                         
                            ?>

<form class="text-left mt-5" method="POST" enctype="multipart/form-data">
                            <div class="md:col-span-6 col-span-6 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">profile</label>
                                    <input type="file" name="photo" class="form-input border border-slate-100 dark:border-slate-800 mt-1" >
                                </div>
                                <img src="upload/photo/<?php echo  "$photo"; ?>" style="border-radius:50%; height:100px; width:100px">

                                
                            <div class="grid grid-cols-1 gap-4 mt-4">
                                <div>
                                    <button type="submit" name="send1" class="btn rounded-md bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white">Update</button>
                                </div>
                            </div>
                        </form>
                        <?php 
                        if(isset($_POST["send1"])){
                            // $photo=$_POST["photo"];
                            $temp = explode(".", $_FILES["photo"]["name"]); //file name get
                            $photo = "photo$company_mobile." . end($temp);      //file name rename to photo and mobile no
                            move_uploaded_file($_FILES["photo"]["tmp_name"], "upload/photo/$photo"); //file uplode 
    
    
                          $sql="UPDATE company SET photo='$photo' WHERE id='$id'";
                          if ($connect->query($sql)) {
                            echo "<script> alert('company update successfully'); window.location.replace('index.php');</script>";
                          } else {
                            echo "<script> alert('user update failed'); window.location.replace('update_profile.php');</script>";
                          }
                              
                        }
                        ?>
                        </div>
                    </div>
                </div><!--end flex-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- End -->

        <!-- Start Footer -->
        <?php include "footer.php"; ?>
        <!-- End Footer -->
  

     

        <!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fixed hidden text-lg rounded-full z-10 bottom-5 end-5 h-9 w-9 text-center bg-emerald-600 text-white justify-center items-center"><i class="uil uil-arrow-up"></i></a>
        <!-- Back to top -->

<?php include "footer_script.php"; ?>
    </body>
</html>