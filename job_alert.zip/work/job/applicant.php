<?php include "config.php";
	session_start();
    if (!isset($_SESSION["company_mobile"]))
    {
        header("Location:login.php?mes=login_error");
    }
  else{
        $company_mobile=$_SESSION["company_mobile"];
        $sql="SELECT * FROM company WHERE company_mobile='$company_mobile'" ;
        $res=$connect->query($sql);
        $row=$res->fetch_assoc();
        $photo=$row["photo"];
        $company_name=$row["company_name"];
        $photo=$row["photo"];
    }
?>

<!DOCTYPE html>
<html lang="en" class="light scroll-smooth" dir="ltr">

<head>
<?php include "header.php"; ?>

    </head>
    
    <body class="dark:bg-slate-900">
        
        <!-- Start Navbar -->
        <?php include "side_nav.php"; ?>
        <!-- End Navbar -->

        <!-- Start Hero -->
        <section class="relative table w-full py-36 bg-[url('../../assets/images/hero/bg.html')] bg-top bg-no-repeat bg-cover">
            <div class="absolute inset-0 bg-emerald-900/90"></div>
            <div class="container">
                <div class="grid grid-cols-1 text-center mt-10">
                    <h3 class="md:text-3xl text-2xl md:leading-snug tracking-wide leading-snug font-medium text-white">Applicants</h3>
                </div><!--end grid-->
            </div><!--end container-->
        </section><!--end section-->
        <div class="relative">
            <div class="shape absolute start-0 end-0 sm:-bottom-px -bottom-[2px] overflow-hidden z-1 text-white dark:text-slate-900">
                <svg class="w-full h-auto" viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div>
        <!-- End Hero -->

        <!-- Start -->
        <section class="relative mt-7 -mt-[42px] md:pb-24 pb-16">
        

            <div class="container mt-10">
                <div class="row">
                <div class="grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-[30px]">
                <!-- <div class="grid col-lg-4"> -->
                <?php
                    $sql = "SELECT * FROM applicant WHERE company_name='$company_name'";
                    $result = $connect->query($sql);
                    $i = 0;
                    while($row=$result->fetch_assoc()) {
                      $i = $i + 1;

                      $id=$row["id"];
                      $company_name=$row["company_name"];
                      $f_name = $row["f_name"];
                      $l_name = $row["l_name"];
                      $dob = $row["dob"];
                      $age = $row["age"];
                      $gender = $row["gender"];
                      $email = $row["email"];
                      $mobile = $row["mobile"];
                      $degree = $row["degree"];
                      $location = $row["location"];
                      $comments = $row["comments"];
                      $resume = $row["resume"];
                      

                      ?>
                    <div class="group relative overflow-hidden bg-white dark:bg-slate-900 shadow hover:shadow-md dark:shadow-gray-700 dark:hover:shadow-gray-700 hover:-mt-2 rounded-md transition-all duration-500 h-fit">
                        <div class="p-6">
                            <div class="flex items-center">
                                <div class="w-14 h-14 min-w-[56px] flex items-center justify-center bg-white dark:bg-slate-900 shadow dark:shadow-gray-700 rounded-md">
                                    <img src="upload/photo/<?php echo "$photo"; ?>" class="h-20 w-20"  alt="">
                                </div>
    
                                <div class="ms-3">
                                    <a href="#" class="inline-block text-[16px] font-semibold hover:text-emerald-600 transition-all duration-500 me-1"><?php echo "$f_name.$l_name"; ?></a>
                                    <span class="inline-block text-sm text-slate-400">DOB :<?php echo "$dob"; ?></span>
                                    <div>
                                        <span class="bg-emerald-600/10 inline-block text-emerald-600 text-xs px-2.5 py-0.5 font-semibold rounded-full me-1">Age:<?php echo "$age"; ?></span>
                                        <span class="text-sm font-medium inline-block me-1">Gender :
                                        <span class="text-slate-400"><?php echo "$gender"; ?></span></span>
                                        <span class="text-sm font-medium inline-block me-1">Email: 
                                         <span class="text-slate-400"><?php echo "$email"; ?></span></span>
                                    </div>
                                    <p class="text-slate-400 py-3">Message :<?php echo "$comments"; ?></p>
                            <span class="bg-emerald-600/10 inline-block text-emerald-600 text-xs px-2.5 py-0.5 font-semibold rounded-full me-1">Degree :<?php echo "$degree"; ?></span>
                            
                            <span class="bg-slate-100 dark:bg-slate-800 inline-block text-slate-900 dark:text-slate-300 text-xs px-2.5 py-0.5 font-semibold rounded-full me-1">Location :<?php echo "$location"; ?></span>

                                </div>
                            </div>
                          
                        </div>

                        <div class="px-6 py-2 bg-slate-50 dark:bg-slate-800 lg:flex justify-between items-center">
                            <div class="lg:inline-block flex justify-between">
                           
                           <button> <a href="upload/resume/<?php echo "$resume"; ?>" class="btn btn-sm rounded-md bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white md:ms-2 w-full lg:w-auto lg:mt-0 mt-4">View Resume</a></button>
                          
                              
                            </div>
                 

                            <a href="applicant.php?delete_id=<?php echo $id; ?>" class="btn btn-sm rounded-md bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white md:ms-2 w-full lg:w-auto lg:mt-0 mt-4">Delete</a>
                        </div>

                    </div><!--end content-->

            <?php } ?>
            <?php
                  if (isset($_GET["delete_id"])) {
                    $delete_id = $_GET["delete_id"];
                    $sql = "DELETE FROM applicant where id='$delete_id'";
                    if ($connect->query($sql)) {
                      echo "<script>alert('Deleted Successfully');
                window.location.replace('applicant.php')</script>";
                    } else {
                      echo "<script>alert('Not Deleted');
                window.location.replace('applicant.php')</script>";
                    }
                  }
                  ?>
                    </div>
                </div><!--end grid-->

            </div><!--end container-->
        </section><!--end section-->
        <!-- End -->

        

        <!-- Start Footer -->
       <?php include "footer.php"; ?>
        <!-- End Footer -->
       

        <!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fixed hidden text-lg rounded-full z-10 bottom-5 end-5 h-9 w-9 text-center bg-emerald-600 text-white justify-center items-center"><i class="uil uil-arrow-up"></i></a>
        <!-- Back to top -->

        <!-- JAVASCRIPTS -->
<?php include "footer_script.php"; ?>
        <!-- JAVASCRIPTS -->
    </body>
</html>