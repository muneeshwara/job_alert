<?php
// Retrieve the form data
$age = $_POST['age'];
$rasi = $_POST['rasi'];
$najathiram = $_POST['najathiram'];

// Establish a con to the database (assuming you have set up a MySQL database)
$host = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'uiboinfo_matrimony';

$con = new mysqli($host, $dbUsername, $dbPassword, $dbName);

// Check for con errors
if ($con->connect_error) {
    die('con failed: ' . $con->connect_error);
}

// Prepare the base query
$query = "SELECT * FROM register WHERE 1=1";

// Check if any filter is provided and modify the query accordingly
if (!empty($age)) {
    $query .= " AND age LIKE '%$age%'";
}

if (!empty($rasi)) {
    $query .= " AND rasi LIKE '%$rasi%'";
}

if (!empty($najathiram)) {
    $query .= " AND najathiram LIKE '%$najathiram%'";
}

// Execute the query
$result = $con->query($query);

// Display the filtered results
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Name: " . $row['age'] . "<br>";
        echo "Email: " . $row['rasi'] . "<br>";
        echo "Phone: " . $row['najathiram'] . "<br><br>";
        echo "Name: " . $row['assets'] . "<br>";
        echo "Email: " . $row['gender'] . "<br>";
        echo "Phone: " . $row['name'] . "<br><br>";
    }
} else {
    echo "No results found.";
}

// Close the database con
$con->close();
?>