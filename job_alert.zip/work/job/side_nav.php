
<nav id="topnav" class="defaultscroll is-sticky">
            <div class="container">
                <!-- Logo container-->
                <a class="logo" href="index.php">
                    <div class="block sm:hidden">
                         <img src="assets/images/logo/fav.png" class="h-10 inline-block dark:hidden"  alt="">
                        <img src="assets/images/logo/fav.png" class="h-10 hidden dark:inline-block"  alt="">
                    </div>
                    <div class="sm:block hidden">
                        <span class="inline-block dark:hidden">
                            <img src="assets/images/logo/fav.png" class="h-[24px] l-dark" alt="">
                            <img src="assets/images/logo/fav.png" class="h-[24px] l-light" alt="">
                        </span>
                        <img src="assets/images/logo/fav.png" class="h-[24px] hidden dark:inline-block" alt="">
                    </div>
                </a>
                <!-- End Logo container-->

                <!-- Start Mobile Toggle -->
                <div class="menu-extras">
                    <div class="menu-item">
                        <a class="navbar-toggle" id="isToggle" onclick="toggleMenu()">
                            <div class="lines">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </a>
                    </div>
                </div>
                <!-- End Mobile Toggle -->
               
                <!--Login button Start-->
                <ul class="buy-button list-none mb-0">
                    <li class="inline-block mb-0">
                        <div class="relative top-[3px]">
                            <i class="uil uil-search text-lg absolute top-[3px] end-3"></i>
                            <input type="text" class="form-input h-9 pe-10 rounded-3xl sm:w-44 w-36 border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900" name="s" id="searchItem" placeholder="Search...">
                        </div>
                    </li>
                    <li class="inline-block ps-1 mb-0">
                        <a href="update_profile.php" class="btn btn-icon rounded-full bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white"><img src="upload/photo/<?php echo "$photo"; ?>" class="rounded-full" alt=""></a>
                    </li>
                </ul>
                <!--Login button End-->

              <?php include "navbar.php"; ?>
                
                <!--end navigation-->
            </div><!--end container-->
        </nav><!--end header-->