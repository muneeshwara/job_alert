<?php include "config.php";
	session_start();
    if (!isset($_SESSION["company_mobile"]))
    {
        header("Location:login.php?mes=login_error");
    }
  else{
        $company_mobile=$_SESSION["company_mobile"];
        $sql="SELECT * FROM company WHERE company_mobile='$company_mobile'";
        $res=$connect->query($sql);
        $row=$res->fetch_assoc();
        $company_mobile=$row["company_mobile"];
        $photo=$row["photo"];
    }
?>
<!DOCTYPE html>
<html lang="en" class="light scroll-smooth" dir="ltr">
 <head>
      <?php include "header.php"; ?>
    </head>
    
    <body class="dark:bg-slate-900">

        <!-- Start Navbar -->
      <?php include "side_nav.php"; ?>
        <!-- End Navbar -->

        <!-- Start Hero -->
        <section class="relative flex py-36 md:h-screen h-auto items-center bg-[url] bg-top bg-no-repeat bg-cover">
            <div class="absolute top-0 start-0 w-full h-full z-0 pointer-events-none overflow-hidden">
                <iframe src="https://player.vimeo.com/video/354421650?background=1&amp;autoplay=1&amp;loop=1&amp;byline=0&amp;title=0" class="absolute top-1/2 start-1/2 ltr:-translate-x-1/2 rtl:translate-x-1/2  -translate-y-1/2 w-screen h-[56.25vw] min-h-screen min-w-[177.77vw]"></iframe>

            </div>
            <div class="absolute inset-0 bg-emerald-900/80"></div>
            <div class="container z-1">
                <div class="grid grid-cols-1 text-center mt-10 relative">
                    <h4 class="lg:leading-normal leading-normal text-4xl lg:text-5xl mb-5 font-bold text-white"> Uibo Job Portal </h4>
                    <p class="text-white/50 text-lg max-w-xl mx-auto">Find Jobs, Employment & Career Opportunities. Some of the companies we've helped recruit excellent applicants over the years.</p>
                
                    <div class="d-flex" id="reserve-form">
                        <div class="md:w-5/6 mx-auto">
                            <div class="lg:col-span-10 mt-8">
                                <div class="bg-white dark:bg-slate-900 border-0 shadow rounded-md p-3">
                                    <form action="#">
                                        <div class="registration-form text-dark text-start">
                                            <div class="grid lg:grid-cols-4 md:grid-cols-2 grid-cols-1 lg:gap-0 gap-6">
                                                <div class="filter-search-form relative filter-border">
                                                    <i class="uil uil-briefcase-alt icons"></i>
                                                    <input name="name" type="text" id="job-keyword" class="form-input filter-input-box bg-gray-50 dark:bg-slate-800 border-0" placeholder="Search your Keywords">
                                                </div>
    
                                                <div class="filter-search-form relative filter-border">
                                                    <i class="uil uil-map-marker icons"></i>
                                                    <select class="form-select" data-trigger name="choices-location" id="choices-location" aria-label="Default select example">
                                                        <option value="AF">Afghanistan</option>
                                                        <option value="AZ">Azerbaijan</option>
                                                        <option value="BS">Bahamas</option>
                                                        <option value="BH">Bahrain</option>
                                                        <option value="CA">Canada</option>
                                                        <option value="CV">Cape Verde</option>
                                                        <option value="DK">Denmark</option>
                                                        <option value="DJ">Djibouti</option>
                                                        <option value="ER">Eritrea</option>
                                                        <option value="EE">Estonia</option>
                                                        <option value="GM">Gambia</option>
                                                    </select>
                                                </div>
                                            
                                                <div class="filter-search-form relative filter-border">
                                                    <i class="uil uil-briefcase-alt icons"></i>
                                                    <select class="form-select" data-trigger name="choices-type" id="choices-type" aria-label="Default select example">
                                                        <option selected="" value="1">Full Time</option>
                                                        <option value="2">Part Time</option>
                                                        <option value="3">Freelancer</option>
                                                        <option value="4">Remote Work</option>
                                                        <option value="5">Office Work</option>
                                                    </select>
                                                </div>
    
                                                <input type="submit" id="search" name="search" style="height: 60px;" class="btn bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white searchbtn submit-btn w-100" value="Search">
                                            </div><!--end grid-->
                                        </div><!--end container-->
                                        
                                    </form>
                                </div>
                            </div><!--ed col-->
                        </div>
                    </div><!--end grid-->

                    <div class="mt-4">
                        <span class="text-white/60"><span class="text-white">Popular Searches :</span> Designer, Developer, Web, IOS, PHP Senior Engineer</span>
                    </div>
                </div><!--end grid-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- End Hero -->

        <!-- Start -->
        <section class="py-24 w-full table relative bg-[url('../../assets/images/hero/bg3.html')] bg-center bg-no-repeat bg-cover jarallax" data-jarallax data-speed="0.5">
            <div class="absolute inset-0 bg-slate-900/40"></div>
            <div class="container relative">
                <div class="grid md:grid-cols-2 grid-cols-1 gap-[30px]">
                    <div>
                        <h5 class="text-xl font-semibold text-white">Register for Candidate company</h5>

                        <ul class="list-none text-white/50 mt-4">
                            <li class="mb-1 flex"><i class="uil uil-check-circle text-white text-xl me-2"></i> It has survived not only five centuries</li>
                            <li class="mb-1 flex"><i class="uil uil-check-circle text-white text-xl me-2"></i> There are many variations of passages</li>
                        </ul>

                        <div class="mt-4">
                            <a href="register.php" class="btn bg-emerald-600 hover:bg-emerald-700 border-emerald-600 dark:border-emerald-600 text-white rounded-full">Apply Now</a>
                        </div>
                    </div><!--end content-->
                    
                    <div>
                        <h5 class="text-xl font-semibold text-white">Register for Companies</h5>

                        <ul class="list-none text-white/50 mt-4">
                            <li class="mb-1 flex"><i class="uil uil-check-circle text-white text-xl me-2"></i> Many desktop publishing packages</li>
                            <li class="mb-1 flex"><i class="uil uil-check-circle text-white text-xl me-2"></i> Contrary to popular belief</li>
                            <li class="mb-1 flex"><i class="uil uil-check-circle text-white text-xl me-2"></i> It is a long established fact that a reader</li>
                        </ul>

                        <div class="mt-4">
                            <a href="job_post.php" class="btn bg-emerald-600 hover:bg-emerald-700 border-emerald-600 dark:border-emerald-600 text-white rounded-full">Post Jobs</a>
                        </div>
                    </div><!--end content-->
                </div><!--end grid-->
            </div><!--end container-->
        </section><!--end section-->
        <!-- End -->

        <!-- Start Footer -->
       <?php include "footer.php"; ?>
        <!-- End Footer -->
        <!-- Switcher -->
        <div class="fixed top-1/4 -left-2 z-50">
            <span class="relative inline-block rotate-90">
                <input type="checkbox" class="checkbox opacity-0 absolute" id="chk">
                <label class="label bg-slate-900 dark:bg-white shadow dark:shadow-gray-800 cursor-pointer rounded-full flex justify-between items-center p-1 w-14 h-8" for="chk">
                    <i class="uil uil-moon text-[20px] text-yellow-500"></i>
                    <i class="uil uil-sun text-[20px] text-yellow-500"></i>
                    <span class="ball bg-white dark:bg-slate-900 rounded-full absolute top-[2px] left-[2px] w-7 h-7"></span>
                </label>
            </span>
        </div>

        <div class="fixed top-1/2 -right-11 z-50 hidden sm:block">
            <a href="https://1.envato.market/jobstack" target="_blank" class="py-1 px-3 relative inline-block rounded-t-md -rotate-90 bg-white dark:bg-slate-900 shadow-md dark:shadow dark:shadow-gray-800 font-semibold"><i class="mdi mdi-cart-outline me-1"></i> Download</a>
        </div>
        <!-- Switcher -->

        <!-- LTR & RTL Mode Code -->
        <div class="fixed top-[40%] -left-3 z-50">
            <a href="#" id="switchRtl">
                <span class="py-1 px-3 relative inline-block rounded-b-md -rotate-90 bg-white dark:bg-slate-900 shadow-md dark:shadow dark:shadow-gray-800 font-semibold rtl:block ltr:hidden" >LTR</span>
                <span class="py-1 px-3 relative inline-block rounded-b-md -rotate-90 bg-white dark:bg-slate-900 shadow-md dark:shadow dark:shadow-gray-800 font-semibold ltr:block rtl:hidden">RTL</span>
            </a>
        </div>
        <!-- LTR & RTL Mode Code --> 

        <!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fixed hidden text-lg rounded-full z-10 bottom-5 end-5 h-9 w-9 text-center bg-emerald-600 text-white justify-center items-center"><i class="uil uil-arrow-up"></i></a>
        <!-- Back to top -->

<?php include "footer_script.php"; ?>
    </body>
</html>