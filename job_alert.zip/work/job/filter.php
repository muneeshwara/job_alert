<?php
// Retrieve the form data
$company_name = $_POST['company_name'];
$company_mobile = $_POST['company_mobile'];
// $najathiram = $_POST['najathiram'];

// Establish a con to the database (assuming you have set up a MySQL database)
$host = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'uibo_job';

$connect = new mysqli($host, $dbUsername, $dbPassword, $dbName);

// Check for con errors
if ($connect->connect_error) {
    die('con failed: ' . $connect->connect_error);
}

// Prepare the base query
$query = "SELECT * FROM company WHERE 1=1";

// Check if any filter is provided and modify the query accordingly
if (!empty($company_name)) {
    $query .= " AND company_name LIKE '%$company_name%'";
}

if (!empty($company_mobile)) {
    $query .= " AND company_mobile LIKE '%$company_mobile%'";
}


// Execute the query
$result = $connect->query($query);

// Display the filtered results

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "company name: " . $row['company_name'] . "<br>";
        echo "mobile: " . $row['company_mobile'] . "<br>";
     
    }
} else {
    echo "No results found.";
}

// Close the database con
$connect->close();
?>