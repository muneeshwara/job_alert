<div id="navigation">
                    <!-- Navigation Menu-->   
                    <ul class="navigation-menu justify-end nav-light">
                        <li class="has-submenu parent-menu-item">
                            <a href="index.php">Home</a>
                           
                        </li>

                        <li class="has-submenu parent-parent-menu-item"><a href="job_post.php"> Jobs Post </a>
                       
                        </li>
                
                        <li class="has-submenu parent-parent-menu-item">
                            <a href="viewjob.php">View Jobs</a>
                            
                        </li>
                        <li class="has-submenu parent-parent-menu-item">
                            <a href="applicant.php">Applicants</a>
                            
                        </li>
                
                        <li><a href="logout.php" class="sub-menu-item">Logout</a></li>
                    </ul><!--end navigation menu-->
                </div>