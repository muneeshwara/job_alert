<?php include "config.php";
	session_start();
    if (!isset($_SESSION["company_mobile"]))
    {
        header("Location:login.php?mes=login_error");
    }
  else{
        $company_mobile=$_SESSION["company_mobile"];
        $sql="SELECT * FROM company WHERE company_mobile='$company_mobile'";
        $res=$connect->query($sql);
        $row=$res->fetch_assoc();
        $company_mobile=$row["company_mobile"];
        $company_name=$row["company_name"];
        $photo=$row["photo"];

    }
?>
<!DOCTYPE html>
<html lang="en" class="light scroll-smooth" dir="ltr">

<head>
<?php include "header.php"; ?>

    </head>
    
    <body class="dark:bg-slate-900">
        
        <!-- Start Navbar -->
        <?php include "side_nav.php"; ?>
        <!-- End Navbar -->

        <!-- Start Hero -->
        <section class="relative table w-full py-36 bg-[url('../../assets/images/hero/bg.html')] bg-top bg-no-repeat bg-cover">
            <div class="absolute inset-0 bg-emerald-900/90"></div>
            <div class="container">
                <div class="grid grid-cols-1 text-center mt-10">
                    <h3 class="md:text-3xl text-2xl md:leading-snug tracking-wide leading-snug font-medium text-white">Job Vacancies</h3>
                </div><!--end grid-->
            </div><!--end container-->
        </section><!--end section-->
        <div class="relative">
            <div class="shape absolute start-0 end-0 sm:-bottom-px -bottom-[2px] overflow-hidden z-1 text-white dark:text-slate-900">
                <svg class="w-full h-auto" viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div>
        <!-- End Hero -->

        <!-- Start -->
        <section class="relative -mt-[42px] md:pb-24 pb-16">
            <div class="container z-1">
                <div class="d-flex" id="reserve-form">
                    <div class="md:w-5/6 mx-auto">
                        <div class="lg:col-span-10">
                            <div class="bg-white dark:bg-slate-900 border-0 shadow rounded-md p-3">
                                <form action="#">
                                    <div class="registration-form text-dark text-start">
                                        <div class="grid lg:grid-cols-4 md:grid-cols-2 grid-cols-1 lg:gap-0 gap-6">
                                            <div class="filter-search-form relative filter-border">
                                                <i class="uil uil-briefcase-alt icons"></i>
                                                <input name="name" type="text" id="job-keyword" class="form-input filter-input-box bg-gray-50 dark:bg-slate-800 border-0" placeholder="Search your Keywords">
                                            </div>

                                            <div class="filter-search-form relative filter-border">
                                                <i class="uil uil-map-marker icons"></i>
                                                <select class="form-select" data-trigger name="choices-location" id="choices-location" aria-label="Default select example">
                                                    <option value="AF">Afghanistan</option>
                                                    <option value="AZ">Azerbaijan</option>
                                                    <option value="BS">Bahamas</option>
                                                    <option value="BH">Bahrain</option>
                                                    <option value="CA">Canada</option>
                                                    <option value="CV">Cape Verde</option>
                                                    <option value="DK">Denmark</option>
                                                    <option value="DJ">Djibouti</option>
                                                    <option value="ER">Eritrea</option>
                                                    <option value="EE">Estonia</option>
                                                    <option value="GM">Gambia</option>
                                                </select>
                                            </div>
                                        
                                            <div class="filter-search-form relative filter-border">
                                                <i class="uil uil-briefcase-alt icons"></i>
                                                <select class="form-select" data-trigger name="choices-type" id="choices-type" aria-label="Default select example">
                                                    <option selected="" value="1">Full Time</option>
                                                    <option value="2">Part Time</option>
                                                    <option value="3">Freelancer</option>
                                                    <option value="4">Remote Work</option>
                                                    <option value="5">Office Work</option>
                                                </select>
                                            </div>

                                            <input type="submit" id="search" name="search" style="height: 60px;" class="btn bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white searchbtn submit-btn w-100" value="Search">
                                        </div><!--end grid-->
                                    </div><!--end container-->
                                </form>
                            </div>
                        </div><!--ed col-->
                    </div>
                </div><!--end grid-->
            </div><!--end container-->

            <div class="container mt-10">
                <div class="row">
                <div class="grid lg:grid-cols-2 md:grid-cols-2 grid-cols-1 gap-[30px]">
                <?php
                    $sql = "SELECT * FROM vacancy WHERE company_name='$company_name'";
                  
                    $result = $connect->query($sql);
                    $i = 0;
                    while ($row = $result->fetch_assoc()) {
                      $i = $i + 1;
                      
                      $id=$row["id"];
                      $job_title=$row["job_title"];
                      $job_type=$row["job_type"];                      
                      $company_name = $row["company_name"];
                      $email = $row["email"];
                      $company_mobile = $row["company_mobile"];
                      $no_of_openings=$row["no_of_openings"];
                      $qualification=$row["qualification"];
                      $job_location=$row["job_location"];
                      $job_district=$row["job_district"];
                      $job_description=$row["job_description"];
                      $experience=$row["experience"];
                      $skills=$row["skills"];
                      $salary=$row["salary"];
                      $job_category=$row["job_category"];
                      $date_posted=$row["date_posted"];

                    ?>
                    <div class="group relative overflow-hidden bg-white dark:bg-slate-900 shadow hover:shadow-md dark:shadow-gray-700 dark:hover:shadow-gray-700 hover:-mt-2 rounded-md transition-all duration-500 h-fit">
                        <div class="p-6">
                            <div class="flex items-center">
                                <div class="w-14 h-14 min-w-[56px] flex items-center justify-center bg-white dark:bg-slate-900 shadow dark:shadow-gray-700 rounded-md">
                                    <img src="upload/photo/<?php echo "$photo"; ?>" class="h-8 w-8"  alt="">
                                </div>
    
                                <div class="ms-3">
                                    <a href="job-detail-three.html" class="inline-block text-[16px] font-semibold hover:text-emerald-600 transition-all duration-500 me-1"><?php echo "$company_name"; ?></a>
                                    <span class="inline-block text-sm text-slate-400">Experience :<?php echo "$experience"; ?></span>
                                    <div>
                                        <span class="bg-emerald-600/10 inline-block text-emerald-600 text-xs px-2.5 py-0.5 font-semibold rounded-full me-1"><?php echo "$job_type"; ?></span>
                                        <span class="text-sm font-medium inline-block me-1">Openings :<span class="text-slate-400"><?php echo "$no_of_openings"; ?></span></span>
                                        <span class="text-sm font-medium inline-block me-1">Salary: <span class="text-slate-400">$ <?php echo "$salary"; ?></span></span>
                                    </div>
                                </div>
                            </div>
    
                            <div class="flex" style="justify-content: space-between;">
                            <p class="text-slate-400 py-3">Company Mobile : <?php echo "$company_mobile"; ?></p>

                            <p class="text-slate-400 py-3"> Email : <?php echo "$email"; ?></p>
    
                            </div>
                           
                            <div>
                                <span class="bg-slate-100 dark:bg-slate-800 inline-block text-slate-900 dark:text-slate-300 text-xs px-2.5 py-0.5 font-semibold rounded-full me-1">Qualification : <?php echo "$qualification"; ?></span>
                              
                                <span class="bg-slate-100 dark:bg-slate-800 inline-block text-slate-900 dark:text-slate-300 text-xs px-2.5 py-0.5 font-semibold rounded-full me-1">Skills : <?php echo "$skills"; ?></span>
                                <span class="bg-slate-100 dark:bg-slate-800 inline-block text-slate-900 dark:text-slate-300 text-xs px-2.5 py-0.5 font-semibold rounded-full me-1">Job Description : <?php echo "$job_description"; ?></span>
                                
                            </div>
                        </div>

                        <div class="px-6 py-2 bg-slate-50 dark:bg-slate-800 lg:flex justify-between items-center">
                            <div class="lg:inline-block flex justify-between">
                                <span class="inline-block me-1 font-semibold"> <a href="job_edit.php?edit_id=<?php echo $id; ?>" class="btn btn-sm bg-emerald-600 hover:bg-emerald-700 border-emerald-600 dark:border-emerald-600 text-white rounded-md">edit</a></span>
                               
                                <span class="inline-block me-1 text-slate-400"><i class="uil uil-map-marker text-[18px] text-slate-900 dark:text-white me-1"></i><?php echo "$job_location"; ?></span>
                              
                            </div>

                            <a href="#" class="btn btn-sm rounded-md bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white md:ms-2 w-full lg:w-auto lg:mt-0 mt-4">delete</a>
                        </div>

                        <!-- <a href="#" class="btn btn-icon rounded-full bg-emerald-600/5 hover:bg-emerald-600 border-emerald-600/10 hover:border-emerald-600 text-emerald-600 hover:text-white absolute top-0 end-0 m-3"><i data-feather="bookmark" class="h-4 w-4"></i></a> -->
                    </div><!--end content-->

            <?php } ?>
            <?php
                  if (isset($_GET["delete_id"])) {
                    $delete_id = $_GET["delete_id"];
                    $sql = "DELETE FROM vacancy where id='$delete_id'";
                    if ($connect->query($sql)) {
                      echo "<script>alert('Deleted Successfully');
                window.location.replace('viewjob.php')</script>";
                    } else {
                      echo "<script>alert('Not Deleted');
                window.location.replace('viewjob.php')</script>";
                    }
                  }
                  ?>
                    </div>
                </div><!--end grid-->

            </div><!--end container-->
        </section><!--end section-->
        <!-- End -->

        

        <!-- Start Footer -->
       <?php include "footer.php"; ?>
        <!-- End Footer -->
       

        <!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fixed hidden text-lg rounded-full z-10 bottom-5 end-5 h-9 w-9 text-center bg-emerald-600 text-white justify-center items-center"><i class="uil uil-arrow-up"></i></a>
        <!-- Back to top -->

        <!-- JAVASCRIPTS -->
<?php include "footer_script.php"; ?>
        <!-- JAVASCRIPTS -->
    </body>
</html>