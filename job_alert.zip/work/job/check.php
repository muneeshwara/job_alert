<?php include "config.php";?>
<!DOCTYPE html>
<html>
<head>
    <title>Filter Page</title>
</head>
<body>
    <form method="POST" action="filter.php">
        <label for="name">Name:</label>
        <input type="text" name="company_name" id="name"><br><br>
        
        <label for="mobile">Company Mobile:</label>
        <input type="text" name="company_mobile" id="company_mobile"><br><br>
        
        <!-- <label for="phone">najathiram:</label>
        <input type="text" name="najathiram" id="phone"><br><br> -->
        
        <input type="submit" value="Filter">
    </form>
</body>
</html>