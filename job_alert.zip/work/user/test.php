<!DOCTYPE html>
<html>
<head>
    <title>Live Search with Filters</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="script.js"></script>
</head>
<body>
    <h2>Live Search with Filters</h2>
    <input type="text" id="search" placeholder="Search...">
    <br><br>
    <label for="category">Category:</label>
    <select id="category">
        <option value="">All</option>
        <option value="Books">Books</option>
        <option value="Electronics">Electronics</option>
        <option value="Clothing">Clothing</option>
    </select>
    <br><br>
    <label for="price">Price Range:</label>
    <input type="number" id="minPrice" placeholder="Min Price">
    <input type="number" id="maxPrice" placeholder="Max Price">
    <br><br>
    <div id="result"></div>


    <?php
// Establishing connection to MySQL server
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "uibo_job";

$connect = new mysqli($servername, $username, $password, $dbname);
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}

// Retrieving search query and filters from AJAX request
$searchText = isset($_POST['search']) ? $_POST['search'] : '';
// $category = isset($_POST['category']) ? $_POST['category'] : '';
// $minPrice = isset($_POST['minPrice']) ? $_POST['minPrice'] : '';
// $maxPrice = isset($_POST['maxPrice']) ? $_POST['maxPrice'] : '';

// Creating the base SQL query
$sql = "SELECT * FROM vacancy WHERE 1=1";

// Adding search text filter
// if(!empty($searchText)){
//     $sql .= " AND (column1 LIKE '%$searchText%' OR column2 LIKE '%$searchText%')";
// }

// Adding category filter
// if(!empty($category)){
//     $sql .= " AND category = '$category'";
// }

// Adding price range filter
// if(!empty($minPrice) && !empty($maxPrice)){
//     $sql .= " AND price BETWEEN $minPrice AND $maxPrice";
// }

// Executing the query
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Displaying search results
        echo "<p>".$row['company_name']." - ".$row['job_location']."</p>";
    }
} else {
    echo "<p>No results found.</p>";
}

$connect->close();
?>


    <script>
        $(document).ready(function(){
    $('#search, #category, #minPrice, #maxPrice').on('keyup change', function(){
        var searchText = $('#search').val();
        // var category = $('#category').val();
        // var minPrice = $('#minPrice').val();
        // var maxPrice = $('#maxPrice').val();

        $.ajax({
            url: 'search.php',
            method: 'post',
            data: {search: searchText},
            success: function(response){
                $('#result').html(response);
            }
        });
    });
});

        </script>
</body>
</html>
