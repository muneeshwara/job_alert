<?php include "config.php";
session_start();
if (!isset($_SESSION["mobile"])) {
    header("Location:login.php?mes=login_error");
} else {
    $mobile = $_SESSION["mobile"];
    $sql = "SELECT * FROM user WHERE mobile='$mobile'";
    $res = $connect->query($sql);
    $row = $res->fetch_assoc();
    $mobile = $row["mobile"];
}
?>
<!DOCTYPE html>
<html lang="en" class="light scroll-smooth" dir="ltr">

<head>
    <?php include "header.php"; ?>
</head>

<body class="dark:bg-slate-900">
    <script>
        function FindAge() {
            var day = document.getElementById("dob").value;
            var DOB = new Date(day);
            var today = new Date();
            var Age = today.getTime() - DOB.getTime();
            Age = Math.floor(Age / (1000 * 60 * 60 * 24 * 365.25));
            document.getElementById("age").value = Age;

        }
    </script>

    <!-- Start Navbar -->

    <?php include "navbar.php"; ?>
    <!-- End Navbar -->

    <!-- Start Hero -->
    <section class="relative table w-full py-36 bg-[url('../../assets/images/hero/bg.html')] bg-top bg-no-repeat bg-cover">
        <div class="absolute inset-0 bg-emerald-900/90"></div>
        <div class="container">
            <div class="grid grid-cols-1 text-center mt-10">
                <h3 class="md:text-3xl text-2xl md:leading-snug tracking-wide leading-snug font-medium text-white">Job Apply</h3>

            </div><!--end grid-->
        </div><!--end container-->

        <div class="absolute text-center z-10 bottom-5 start-0 end-0 mx-3">
            <ul class="breadcrumb tracking-[0.5px] breadcrumb-light mb-0 inline-block">
                <li class="inline breadcrumb-item text-[15px] font-semibold duration-500 ease-in-out text-white/50 hover:text-white"><a href="index.php">Uibo</a></li>
                <li class="inline breadcrumb-item text-[15px] font-semibold duration-500 ease-in-out text-white" aria-current="page">Job Apply</li>
            </ul>
        </div>
    </section><!--end section-->
    <div class="relative">
        <div class="shape absolute start-0 end-0 sm:-bottom-px -bottom-[2px] overflow-hidden z-1 text-slate-50 dark:text-slate-800">
            <svg class="w-full h-auto" viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
            </svg>
        </div>
    </div>
    <!-- End Hero -->

    <!-- Start -->
    <section class="relative bg-slate-50 dark:bg-slate-800 lg:py-24 py-16">
        <div class="container">
            <div class="lg:flex justify-center">
                <div class="lg:w-2/3">
                    <div class="p-6 bg-white dark:bg-slate-900 shadow dark:shadow-gray-700 rounded-md">
                        <form class="text-left" method="POST" enctype="multipart/form-data">
                            <div class="grid grid-cols-1">
                                <h5 class="text-lg font-semibold">Job apply</h5>
                            </div>

                            <div class="grid grid-cols-12 gap-4 mt-4">
                                <div class="col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Company Name</label>

                                    <?php
                                    if (isset($_GET["company_name"])) {
                                        $company_name = $_GET["company_name"];
                                        $sql = "SELECT * FROM company WHERE company_name='$company_name'";
                                        $result = $connect->query($sql);
                                        $row = $result->fetch_assoc();
                                           
                                            $id = $row["id"];
                                            $company_name = $row["company_name"];
                                            $company_mobile = $row["company_mobile"];
                                            $email = $row["email"];
                                            $password = $row["password"];
                                            $street = $row["street"];
                                            $location = $row["location"];
                                            $district = $row["district"];
                                            $taluga = $row["taluga"];
                                            $pincode = $row["pincode"];
                                            $photo = $row["photo"];
                                    }
                                    ?>
                                        <input id="RegisterName" type="text" name="company_name" value="<?php echo "$company_name";  ?>" readonly class="form-input border border-slate-100 dark:border-slate-800 mt-1">
                                   
                                </div>

                                <div class="col-span-6 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">First Name</label>
                                    <input id="RegisterName" type="text" name="f_name" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="Aswath">
                                </div>

                                <div class="md:col-span-6 col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Last Name</label>
                                    <input type="text" name="l_name" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="S">


                                </div>
                                <div class="md:col-span-6 col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Date of Birth</label>
                                    <input type="date" name="dob" id="dob" class="form-input border border-slate-100 dark:border-slate-800 mt-1">


                                </div>
                                <div class="md:col-span-6 col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Age</label>
                                    <input type="text" name="age" id="age" onmousemove="FindAge()" name="age" value="<?php echo "$age"; ?>" class="form-input border border-slate-100 dark:border-slate-800 mt-1">


                                </div>

                                <div class="md:col-span-6 col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Gender</label>

                                    <select class="form-select form-input border border-slate-100 dark:border-slate-800 mt-1" name="gender">
                                        <option valu="select">select</option>
                                        <option value="male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>

                                </div>
                                <div class="col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Email Address:</label>
                                    <input id="RegisterName" type="email" name="email" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="uiboinfotech@gmail.com">
                                </div>



                                <div class="md:col-span-6 col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Mobile</label>
                                    <input type="text" name="mobile" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="9876543210">
                                </div>


                                <div class="md:col-span-6 col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Degree</label>
                                    <input type="text" name="degree" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="BE">
                                </div>

                                <div class="md:col-span-6 col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Address</label>
                                    <input type="text" name="location" class="form-input border border-slate-100 dark:border-slate-800 mt-1" placeholder="chennai">


                                </div>

                                <div class="md:col-span-12 col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Coverting Letter:</label>
                                
                                    <textarea name="comments" id="comments" class="form-input border border-slate-100 dark:border-slate-800 mt-1 textarea" placeholder="Message "></textarea>

                                </div>

                                <div class="md:col-span-6 col-span-12 ltr:text-left rtl:text-right">
                                    <label class="font-semibold">Upload Resume:</label>
                                    <input class="relative form-input border border-slate-100 dark:border-slate-800 file:h-10 file:-mx-3 file:-my-2 file:cursor-pointer file:rounded-none file:border-0 file:px-3 file:text-neutral-700 bg-clip-padding px-3 py-1.5 file:me-3 mt-1" id="multiple_files" name="resume" type="file" multiple>

                                </div>
                        
                            </div>


                            <div class="grid grid-cols-1 gap-4 mt-4">
                                <div>
                                    <button type="submit" name="send" class="btn rounded-md bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white">Apply Now</button>
                                </div>
                            </div>
                        </form><!--end form-->

                        <?php
                        if (isset($_POST["send"])) {
                            $company_name=$_POST["company_name"];
                            $f_name = $_POST["f_name"];
                            $l_name = $_POST["l_name"];
                            $dob = $_POST["dob"];
                            $age = $_POST["age"];
                            $gender = $_POST["gender"];
                            $email = $_POST["email"];
                            $mobile = $_POST["mobile"];
                            $degree = $_POST["degree"];
                            $location = $_POST["location"];
                            $comments = $_POST["comments"];
                            $resume = $_POST["resume"];

                            $temp = explode(".", $_FILES["resume"]["name"]); //file name get
                            $resume = "resume$mobile." . end($temp);      //file name rename to photo and mobile no
                            move_uploaded_file($_FILES["resume"]["tmp_name"], "../job/upload/resume/$resume"); //file uplode 



                            $sql = "INSERT INTO applicant(id, company_name ,f_name, l_name, dob, age, gender, email, mobile, degree, location, comments, resume) VALUES(null, '$company_name', '$f_name', '$l_name', '$dob', '$age', '$gender', '$email', '$mobile', '$degree', '$location', '$comments', '$resume')";

                            if ($connect->query($sql)) {
                                echo "<script> alert('job applied successfully');window.location.replace('index.php');</script>";
                            } else {
                                echo "<script> alert('job applied failed');window.location.replace('job-apply.php');</script>";
                            }
                        }
                        ?>


                    </div>
                </div>
            </div><!--end flex-->
        </div><!--end container-->
    </section><!--end section-->
    <!-- End -->

    <?php include "footer.php"; ?>
    <!-- End Footer -->
    <!-- Switcher -->
    <div class="fixed top-1/4 -left-2 z-50">
        <span class="relative inline-block rotate-90">
            <input type="checkbox" class="checkbox opacity-0 absolute" id="chk">
            <label class="label bg-slate-900 dark:bg-white shadow dark:shadow-gray-800 cursor-pointer rounded-full flex justify-between items-center p-1 w-14 h-8" for="chk">
                <i class="uil uil-moon text-[20px] text-yellow-500"></i>
                <i class="uil uil-sun text-[20px] text-yellow-500"></i>
                <span class="ball bg-white dark:bg-slate-900 rounded-full absolute top-[2px] left-[2px] w-7 h-7"></span>
            </label>
        </span>
    </div>


    <!-- Back to top -->
    <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fixed hidden text-lg rounded-full z-10 bottom-5 end-5 h-9 w-9 text-center bg-emerald-600 text-white justify-center items-center"><i class="uil uil-arrow-up"></i></a>
    <!-- Back to top -->

    <?php include "footer_script.php"; ?>
</body>

</html>