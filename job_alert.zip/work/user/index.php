<?php 
include "config.php";
session_start();
    if (!isset($_SESSION["mobile"]))
    {
        header("Location:login.php?mes=login_error");
    }
	else{
		$mobile=$_SESSION["mobile"];
        $sql="SELECT * FROM company";
        $res=$connect->query($sql);
        $row=$res->fetch_assoc();
        $photo1=$row["photo"];
	}
?>

<!DOCTYPE html>
<html lang="en" class="light scroll-smooth" dir="ltr">
 <head>
       <?php include "header.php"; ?>
    </head>
    
    <body class="dark:bg-slate-900">

        <!-- Start Navbar -->
        <?php include "navbar.php"; ?>
        <!-- End Navbar -->

        <section class="py-36 md:h-screen h-auto items-center flex relative overflow-hidden" id="home">
            <div class="container relative">
                <div class="grid md:grid-cols-12 grid-cols-1 items-center gap-[30px]">
                    <div class="lg:col-span-7 md:col-span-6 mt-14 md:mt-0">
                        <div class="lg:me-8">
                            <h4 class="lg:leading-normal leading-normal text-4xl lg:text-5xl mb-5 font-bold">Find the <span class="before:block before:absolute before:-inset-2 before:-skew-y-6 before:bg-emerald-600 relative inline-block"><span class="relative text-white font-bold">Best Job</span></span> <br> offer for you.</h4>
                    
                            <p class="text-slate-400 text-lg max-w-xl">Find Jobs, Employment & Career Opportunities. Some of the companies we've helped recruit excellent applicants over the years.</p>
                    
                            <div class="bg-white dark:bg-slate-900 border-0 shadow rounded p-3 mt-4">
                                <form action="#">
                                    <div class="registration-form text-dark text-start">
                                        <div class="grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 lg:gap-0 gap-6">
                                            <div class="filter-search-form relative filter-border">
                                                <i class="uil uil-briefcase-alt icons"></i>
                                                <input name="name" type="text" id="job-keyword" class="form-input filter-input-box bg-gray-50 dark:bg-slate-800 border-0" placeholder="Search...">
                                            </div>

                                            <div class="filter-search-form relative filter-border">
                                                <i class="uil uil-map-marker icons"></i>
                                                <select class="form-select" data-trigger name="choices-location" id="choices-location" aria-label="Default select example">
                                                    <option value="BS">Bahamas</option>
                                                    <option value="BH">Bahrain</option>
                                                    <option value="CA">Canada</option>
                                                    <option value="DK">Denmark</option>
                                                    <option value="DJ">Djibouti</option>
                                                    <option value="ER">Eritrea</option>
                                                    <option value="EE">Estonia</option>
                                                    <option value="GM">Gambia</option>
                                                </select>
                                            </div>

                                            <input type="submit" id="search" name="search" style="height: 60px;" class="btn bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white searchbtn submit-btn w-100" value="Search">
                                        </div><!--end grid-->
                                    </div><!--end container-->
                                </form>
                            </div>

                            <div class="mt-2">
                                <span class="text-slate-400"><span class="text-dark">Popular Searches :</span> Designer, Developer, Web, IOS, PHP Senior Engineer</span>
                            </div>
                        </div>
                    </div>

                    <div class="lg:col-span-5 md:col-span-6">
                        <div class="relative">
                            <div class="relative flex justify-end">
                                <img src="assets/images/about/ab01.jpg" class="lg:w-[400px] w-[280px] rounded-xl shadow dark:shadow-gray-700" alt="">
                                <div class="absolute lg:bottom-20 -bottom-24 xl:-end-20 lg:-end-10 end-2 p-4 rounded-lg shadow-md dark:shadow-gray-800 bg-white dark:bg-slate-900 w-60 z-2">
                                    <h5 class="text-lg font-semibold mb-3">5k+ candidates get job</h5>
                                    
                                    <ul class="list-none relative">
                                        <li class="inline-block relative"><a href="#"><img src="assets/images/team/01.jpg" class="w-10 h-10 rounded-full shadow-md dark:shadow-gray-700 border-4 border-white dark:border-slate-900 relative hover:z-1 hover:scale-105 transition-all duration-500" alt=""></a></li>
                                        <li class="inline-block relative -ms-3"><a href="#"><img src="assets/images/team/02.jpg" class="w-10 h-10 rounded-full shadow-md dark:shadow-gray-700 border-4 border-white dark:border-slate-900 relative hover:z-1 hover:scale-105 transition-all duration-500" alt=""></a></li>
                                        <li class="inline-block relative -ms-3"><a href="#"><img src="assets/images/team/03.jpg" class="w-10 h-10 rounded-full shadow-md dark:shadow-gray-700 border-4 border-white dark:border-slate-900 relative hover:z-1 hover:scale-105 transition-all duration-500" alt=""></a></li>
                                        <li class="inline-block relative -ms-3"><a href="#"><img src="assets/images/team/04.jpg" class="w-10 h-10 rounded-full shadow-md dark:shadow-gray-700 border-4 border-white dark:border-slate-900 relative hover:z-1 hover:scale-105 transition-all duration-500" alt=""></a></li>
                                        <li class="inline-block relative -ms-3"><a href="#"><img src="assets/images/team/05.jpg" class="w-10 h-10 rounded-full shadow-md dark:shadow-gray-700 border-4 border-white dark:border-slate-900 relative hover:z-1 hover:scale-105 transition-all duration-500" alt=""></a></li>
                                        <li class="inline-block relative -ms-3"><a href="#" class="btn btn-icon table-cell rounded-full bg-emerald-600 hover:bg-emerald-700 border-emerald-600 hover:border-emerald-700 text-white hover:z-1 hover:scale-105"><i class="uil uil-plus"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="absolute md:-start-5 start-0 -bottom-16">
                                <img src="assets/images/about/ab04.jpg" class="lg:w-[280px] w-[200px] border-8 border-white dark:border-slate-900 rounded-xl" alt="">

                                <div class="absolute flex justify-between items-center -top-6 md:-start-10 start-2 p-4 rounded-lg shadow-md dark:shadow-gray-800 bg-white dark:bg-slate-900 w-max">
                                    <i class="uil uil-bell text-[24px] text-amber-500"></i>
                                    <p class="text-lg font-semibold mb-0 ms-2">Job Alert Subscribe</p>
                                </div>
                            </div>

                            <div class="overflow-hidden absolute md:h-[500px] h-[400px] md:w-[500px] w-[400px] bg-gradient-to-tl to-emerald-600/5 via-emerald-600/50 from-emerald-600 bottom-1/2 translate-y-1/2 start-1/2 ltr:-translate-x-1/2 rtl:translate-x-1/2 -z-1 rounded-full"></div>
                        </div>
                    </div>
                </div>
            </div><!--end container-->
        </section><!--end section-->
        <!-- Start Hero -->
        <!-- <section class="relative table w-full py-36 bg-[url('../../assets/images/hero/bg.html')] bg-top bg-no-repeat bg-cover">
            <div class="absolute inset-0 bg-emerald-900/90"></div>
            <div class="container">
                <div class="grid grid-cols-1 text-center mt-10">
                    <h3 class="md:text-3xl text-2xl md:leading-snug tracking-wide leading-snug font-medium text-white">Job Vacancies</h3>
                </div>
                end grid
            </div>
            end container
        </section>
        end section
        <div class="relative">
            <div class="shape absolute start-0 end-0 sm:-bottom-px -bottom-[2px] overflow-hidden z-1 text-white dark:text-slate-900">
                <svg class="w-full h-auto" viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor"></path>
                </svg>
            </div>
        </div> -->
        <!-- End Hero -->

        <!-- Start -->
        <section class="relative -mt-[42px] md:pb-24 pb-16">
           

            <div class="container mt-10">
                <div class="grid lg:grid-cols-3 md:grid-cols-2 gap-[30px]">

                <?php
                    $sql = "SELECT * FROM vacancy";
                    $result = $connect->query($sql);
                    $i = 0;
                    while ($row = $result->fetch_assoc()) {
                      $i = $i + 1;
                      
                      $id=$row["id"];
                      $job_title=$row["job_title"];
                      $job_type=$row["job_type"];                      
                      $company_name = $row["company_name"];
                      $email = $row["email"];
                      $company_mobile = $row["company_mobile"];
                      $no_of_openings=$row["no_of_openings"];
                      $qualification=$row["qualification"];
                      $job_location=$row["job_location"];
                      $job_district=$row["job_district"];
                      $job_description=$row["job_description"];
                      $experience=$row["experience"];
                      $skills=$row["skills"];
                      $salary=$row["salary"];
                      $job_category=$row["job_category"];
                      $date_posted=$row["date_posted"];

                    ?>

                    <div class="group p-6 rounded-lg border border-emerald-600/20 dark:border-emerald-600/40 bg-white dark:bg-slate-900 hover:bg-emerald-600/[0.02] hover:dark:bg-emerald-600/5 hover:shadow-md hover:shadow-emerald-600/5 transition-all duration-500">
                        <div class="flex justify-between items-start">
                            <div>
                                <div class="w-14 h-14 flex items-center justify-center bg-white dark:bg-slate-900 shadow dark:shadow-gray-700 rounded-full mb-2">
                                    <img src="../job/upload/photo/<?php echo "$photo1"; ?>" class="h-8 w-8"  alt="">
                                </div>
                                <a  class="text-lg hover:text-emerald-600 font-semibold transition-all duration-500"><?php echo "$company_name"; ?></a>
                            </div>

                            <div class="flex items-center">
                              
                                <a href="job_apply.php?company_name=<?php echo $company_name; ?>" class="btn btn-icon rounded-full bg-emerald-600/5 group-hover:bg-emerald-600 border-emerald-600/10 text-emerald-600 group-hover:text-white ms-1"><i class="uil uil-arrow-up-right"></i></a>
                            </div>
                        </div>

                        <div class="mt-3">
                            <a  class="text-xl hover:text-emerald-600 font-semibold transition-all duration-500">Job Title:<?php echo "$job_title"; ?></a>
                            <div class="flex" style="justify-content:space-between;">
                 
                            <p class="text-slate-400 mt-2">Experience: <?php echo "$experience"; ?></p>
                            <p class="text-slate-400 mt-2">date: <?php echo "$date_posted"; ?></p>

                            </div>
                            <div class="mt-3">
                                <a >
                                    <span class="bg-orange-500/5 hover:bg-orange-500/20 dark:bg-orange-500/10 hover:dark:bg-orange-500/30 inline-block text-orange-500 px-4 text-[14px] font-medium rounded-full mt-2 me-1 transition-all duration-500"><?php echo "$job_type"; ?></span>
                                </a>
                                <a >
                                    <span class="bg-purple-600/5 hover:bg-purple-600/20 dark:bg-purple-600/10 hover:dark:bg-purple-600/30 inline-block text-purple-600 px-4 text-[14px] font-medium rounded-full mt-2 me-1 transition-all duration-500">$ <?php echo "$salary"; ?></span>
                                </a>
                                <a>
                                    <span class="bg-emerald-600/5 hover:bg-emerald-600/20 dark:bg-emerald-600/10 hover:dark:bg-emerald-600/30 inline-block text-emerald-600 px-4 text-[14px] font-medium rounded-full mt-2 transition-all duration-500"><i class="uil uil-map-marker"></i> <?php echo "$job_location"; ?></span>
                                </a>
                            </div>
                        </div>
                    </div><!--end content-->

                    <?php } ?>
    
                </div><!--end grid-->

                
            </div><!--end container-->

        </section><!--end section-->
        <!-- End -->

        

        <!-- Start Footer -->
       <?php include "footer.php"; ?>
        <!-- End Footer -->
      

        <!-- Back to top -->
        <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top fixed hidden text-lg rounded-full z-10 bottom-5 end-5 h-9 w-9 text-center bg-emerald-600 text-white justify-center items-center"><i class="uil uil-arrow-up"></i></a>
        <!-- Back to top -->

        <!-- JAVASCRIPTS -->
<?php include "footer_script.php"; ?>
        <!-- JAVASCRIPTS -->

</body>
</html>