<?php include "config.php";?>
<!DOCTYPE html>
<html>
<head>
    <title>Filter Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-1"></div>
            <div class="col-lg-10 col-md-12 col-12 mt-5 d-flex justify-content-around"  style="border: 1px solid lightgray;padding: 10px 20px;border-radius:10px;box-shadow:4px 4px 5px lightgray">
            <form method="POST" class="d-flex" action="filter.php">
        <!-- <label for="name">age:</label> -->
        <!-- <input type="text" name="age" class="form-control" style="border:none" id="name" placeholder="Age"><span style="color:black;font-size:38px">|</span><br> -->
        <select class="form-control" style="border: none;" placeholder="job_location" name="job_location" >
                        <?php
                        echo "<option value=''>job_location</option>";
                        $sql = "SELECT job_location FROM vacancy GROUP BY job_location";
                        $result = $connect->query($sql);
                        while ($row = $result->fetch_assoc()) {

                            $job_location = $row["job_location"];
                            echo "<option value='$job_location'>$job_location</option>";
                        }
                        ?>
                    </select>
                    <span style="color:black;font-size:38px">|</span>
        <!-- <label for="email">rasi:</label> -->
        <select class="form-control" style="margin-left:30px;border:none" placeholder="company_name" name="company_name" >
                        <?php
                        echo "<option value=''>company_name</option>";
                        $sql = "SELECT company_name FROM vacancy GROUP BY company_name";
                        $result = $connect->query($sql);
                        while ($row = $result->fetch_assoc()) {

                            $company_name = $row["company_name"];
                            echo "<option value='$company_name'>$company_name</option>";
                        }
                        ?>
                    </select><span style="color:black;font-size:38px">|</span>
        
        <!-- <label for="phone">najathiram:</label> -->
        <select class="form-control"  style="margin-left:30px;border:none" placeholder="job_title" name="job_title" >
                        <?php
                        echo "<option value=''>job_title</option>";
                        $sql = "SELECT job_title FROM vacancy GROUP BY job_title";
                        $result = $connect->query($sql);
                        while ($row = $result->fetch_assoc()) {

                            $job_title = $row["job_title"];
                            echo "<option value='$job_title'>$job_title</option>";
                        }
                        ?>
                    </select>
        
        <!-- <input type="submit" class="btn" style="background-color: blue;" value="Filter"> -->
        <button type="submit" value="filter" >filter</button>
    </form>
            </div>
            <div class="col-lg-1"></div>

      
        </div>
    </div>
   
</body>
</html>